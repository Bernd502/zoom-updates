rootProject.name = "MaceCorePickup"
