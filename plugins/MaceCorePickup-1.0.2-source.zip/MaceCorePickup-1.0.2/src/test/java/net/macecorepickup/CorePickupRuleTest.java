package net.macecorepickup;

import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class CorePickupRuleTest {
    private final CorePickupRule rule = new CorePickupRule(List.of("speed_core", "wind", "ice_core"));

    @Test void recognizesOnlyConfiguredBuffedItemsIds() {
        assertTrue(rule.matches("speed_core"));
        assertTrue(rule.matches("WIND"));
        assertFalse(rule.matches("heart_egg"));
        assertFalse(rule.matches("some_other_heavy_core"));
        assertFalse(rule.matches(null));
    }

    @Test void invalidOrEmptyCoreListsCannotSilentlyDisableMatching() {
        assertThrows(IllegalArgumentException.class, () -> new CorePickupRule(List.of()));
        assertThrows(IllegalArgumentException.class, () -> new CorePickupRule(List.of("speed_core", "bad:id")));
    }

    @Test void blocksBothPickupOrders() {
        assertTrue(CorePickupRule.blocksPickup(true, false, true, false));
        assertTrue(CorePickupRule.blocksPickup(false, true, false, true));
        assertFalse(CorePickupRule.blocksPickup(true, false, false, false));
        assertFalse(CorePickupRule.blocksPickup(false, true, false, false));
    }

}
