package net.macecorepickup;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.inventory.InventoryPickupItemEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.player.PlayerAttemptPickupItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.ItemFrame;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.Material;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

public final class MaceCorePickupPlugin extends JavaPlugin implements Listener {
    private final Map<UUID, Long> lastNotice = new HashMap<>();
    private NamespacedKey itemIdKey;
    private CorePickupRule rule;
    private Set<String> coreDisplayNames;
    private boolean protectionEnabled;

    @Override public void onEnable() {
        saveDefaultConfig();
        itemIdKey = NamespacedKey.fromString(getConfig().getString("buffed-item-key", ""));
        try { rule = new CorePickupRule(getConfig().getStringList("core-ids")); }
        catch (IllegalArgumentException error) {
            getLogger().severe(error.getMessage());
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }
        coreDisplayNames = getConfig().getStringList("core-display-names").stream()
                .map(name -> name.toLowerCase(Locale.ROOT)).collect(Collectors.toUnmodifiableSet());
        if (itemIdKey == null) {
            getLogger().severe("Configure a valid buffed-item-key and at least one core ID; disabling.");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }
        protectionEnabled = getConfig().getBoolean("enabled", true);
        Bukkit.getPluginManager().registerEvents(this, this);
        Bukkit.getScheduler().runTaskTimer(this, this::auditPlayers, 5L, 5L);
        if (!Bukkit.getPluginManager().isPluginEnabled("BuffedItems"))
            getLogger().warning("BuffedItems is not enabled. No carried items will match until it is available.");
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (mustBlockPickup(player, event.getItem().getItemStack())) {
            event.setCancelled(true);
            notice(player);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onAttemptPickup(PlayerAttemptPickupItemEvent event) {
        Player player = event.getPlayer();
        if (mustBlockPickup(player, event.getItem().getItemStack())) {
            event.setCancelled(true);
            notice(player);
        }
    }

    private boolean mustBlockPickup(Player player, ItemStack groundItem) {
        return appliesTo(player) && CorePickupRule.blocksPickup(isMace(groundItem), isCore(groundItem), hasCore(player), hasMace(player));
    }

    private boolean appliesTo(Player player) { return protectionEnabled && !player.isOp(); }

    /** Covers shift-click, cursor placement, hotbar swaps and crafting-result pickup. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player) || !appliesTo(player)) return;
        if (event.getClickedInventory() == null) return;
        int topSize = event.getView().getTopInventory().getSize();
        boolean top = event.getRawSlot() < topSize;
        InventoryType type = event.getView().getTopInventory().getType();
        boolean storage = type != InventoryType.CRAFTING && type != InventoryType.CREATIVE && type != InventoryType.PLAYER;
        ItemStack current = event.getCurrentItem(), cursor = event.getCursor();
        ItemStack hotbar = event.getClick() == ClickType.NUMBER_KEY && event.getHotbarButton() >= 0
                ? player.getInventory().getItem(event.getHotbarButton()) : null;
        ItemStack offhand = event.getClick() == ClickType.SWAP_OFFHAND ? player.getInventory().getItemInOffHand() : null;
        boolean storingMace = storage && (top && (isMace(cursor) || isMace(hotbar) || isMace(offhand))
                || !top && event.isShiftClick() && isMace(current));
        boolean enteringPlayerInventory = top && (isMace(current) && hasCore(player) || isCore(current) && hasMace(player))
                || !top && (isMace(cursor) && hasCore(player) || isCore(cursor) && hasMace(player));
        boolean bundleInsert = (isBundle(current) && isMace(cursor) || isBundle(cursor) && isMace(current));
        if (storingMace || enteringPlayerInventory || bundleInsert) {
            event.setCancelled(true);
            notice(player);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player) || !appliesTo(player)) return;
        InventoryType type = event.getView().getTopInventory().getType();
        boolean storage = type != InventoryType.CRAFTING && type != InventoryType.CREATIVE && type != InventoryType.PLAYER;
        int topSize = event.getView().getTopInventory().getSize();
        if (storage && event.getNewItems().entrySet().stream().anyMatch(entry -> entry.getKey() < topSize && isMace(entry.getValue()))
                || isMace(event.getOldCursor()) && hasCore(player)
                || isCore(event.getOldCursor()) && hasMace(player)) {
            event.setCancelled(true);
            notice(player);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onHopperMove(InventoryMoveItemEvent event) {
        if (protectionEnabled && isMace(event.getItem())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onHopperPickup(InventoryPickupItemEvent event) {
        if (protectionEnabled && isMace(event.getItem().getItemStack())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onEntityStore(PlayerInteractEntityEvent event) {
        Player player = event.getPlayer();
        if (!appliesTo(player)) return;
        if ((event.getRightClicked() instanceof ItemFrame || event.getRightClicked() instanceof ArmorStand)
                && isMace(player.getInventory().getItem(event.getHand()))) {
            event.setCancelled(true);
            notice(player);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onArmorStandStore(PlayerArmorStandManipulateEvent event) {
        if (appliesTo(event.getPlayer()) && isMace(event.getPlayerItem())) {
            event.setCancelled(true);
            notice(event.getPlayer());
        }
    }

    /** Repairs pre-existing conflicts and items inserted by commands or other plugins without deleting them. */
    private void auditPlayers() {
        if (!protectionEnabled) return;
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!appliesTo(player) || !hasCore(player)) continue;
            PlayerInventory inventory = player.getInventory();
            boolean removed = false;
            for (int slot = 0; slot < inventory.getStorageContents().length; slot++) {
                ItemStack item = inventory.getItem(slot);
                if (!isMace(item)) continue;
                inventory.setItem(slot, null);
                player.getWorld().dropItemNaturally(player.getLocation(), item);
                removed = true;
            }
            if (isMace(inventory.getItemInOffHand())) {
                ItemStack item = inventory.getItemInOffHand();
                inventory.setItemInOffHand(null);
                player.getWorld().dropItemNaturally(player.getLocation(), item);
                removed = true;
            }
            if (isMace(player.getItemOnCursor())) {
                ItemStack item = player.getItemOnCursor();
                player.setItemOnCursor(null);
                player.getWorld().dropItemNaturally(player.getLocation(), item);
                removed = true;
            }
            ItemStack[] armor = inventory.getArmorContents();
            for (int slot = 0; slot < armor.length; slot++) {
                if (!isMace(armor[slot])) continue;
                ItemStack item = armor[slot];
                armor[slot] = null;
                player.getWorld().dropItemNaturally(player.getLocation(), item);
                removed = true;
            }
            if (removed) inventory.setArmorContents(armor);
            if (removed) { player.updateInventory(); notice(player); }
        }
    }

    private static boolean isMace(ItemStack item) { return item != null && item.getType() == Material.MACE; }
    private static boolean isBundle(ItemStack item) { return item != null && item.getType().name().endsWith("BUNDLE"); }

    private boolean hasMace(Player player) {
        for (ItemStack item : player.getInventory().getStorageContents()) if (isMace(item)) return true;
        return isMace(player.getInventory().getItemInOffHand()) || isMace(player.getItemOnCursor());
    }

    private void notice(Player player) {
        long now = System.currentTimeMillis();
        long cooldown = Math.max(0, getConfig().getLong("message-cooldown-ms", 3000));
        Long previous = lastNotice.get(player.getUniqueId());
        if (previous == null || now - previous >= cooldown) {
            lastNotice.put(player.getUniqueId(), now);
            String message = getConfig().getString("blocked-message", "&cYou cannot carry a mace and a core together or store a mace.");
            if ("&cYou cannot pick up a mace while carrying a core.".equals(message))
                message = "&cYou cannot carry a mace and a core together or store a mace.";
            if (message != null && !message.isBlank()) player.sendMessage(ChatColor.translateAlternateColorCodes('&', message));
        }
    }

    @EventHandler public void onQuit(PlayerQuitEvent event) {
        lastNotice.remove(event.getPlayer().getUniqueId());
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        // Permission plugins cannot grant a non-operator the power to disable this rule.
        if (sender instanceof Player player && !player.isOp()) {
            sender.sendMessage(ChatColor.RED + "Only operators can change mace pickup protection.");
            return true;
        }
        if (!sender.hasPermission("macecorepickup.admin")) {
            sender.sendMessage(ChatColor.RED + "You do not have permission.");
            return true;
        }
        if (args.length > 1) return false;
        String action = args.length == 0 ? "status" : args[0].toLowerCase(Locale.ROOT);
        switch (action) {
            case "on" -> setProtectionEnabled(true);
            case "off" -> setProtectionEnabled(false);
            case "toggle" -> setProtectionEnabled(!protectionEnabled);
            case "status" -> { }
            case "inspect" -> {
                if (!(sender instanceof Player player)) { sender.sendMessage("Hold a core or mace in-game, then run /macecorepickup inspect."); return true; }
                ItemStack held = player.getInventory().getItemInMainHand();
                sender.sendMessage(ChatColor.YELLOW + "Held: " + held.getType() + ", recognized core: " + isCore(held)
                        + ", carrying core: " + hasCore(player) + ", carrying mace: " + hasMace(player));
                if (held.hasItemMeta()) for (NamespacedKey key : held.getItemMeta().getPersistentDataContainer().getKeys()) {
                    if (!key.getNamespace().equals("buffeditems")) continue;
                    String value = held.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.STRING);
                    sender.sendMessage(ChatColor.GRAY + key.toString() + " = " + (value == null ? "<not a string>" : value));
                }
                return true;
            }
            default -> { return false; }
        }
        sender.sendMessage((protectionEnabled ? ChatColor.GREEN : ChatColor.YELLOW)
                + "Mace/core and mace storage protection is " + (protectionEnabled ? "ON" : "OFF") + ".");
        return true;
    }

    private void setProtectionEnabled(boolean value) {
        protectionEnabled = value;
        getConfig().set("enabled", value);
        saveConfig();
        lastNotice.clear();
        getLogger().info("Mace/core and mace storage protection " + (value ? "enabled" : "disabled") + " by an operator.");
    }

    @Override public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length != 1 || sender instanceof Player player && !player.isOp()
                || !sender.hasPermission("macecorepickup.admin")) return List.of();
        return List.of("on", "off", "toggle", "status", "inspect").stream()
                .filter(option -> option.startsWith(args[0].toLowerCase(Locale.ROOT))).toList();
    }

    private boolean hasCore(Player player) {
        PlayerInventory inventory = player.getInventory();
        for (ItemStack item : inventory.getStorageContents()) if (isCore(item)) return true;
        for (ItemStack item : inventory.getArmorContents()) if (isCore(item)) return true;
        return isCore(inventory.getItemInOffHand()) || isCore(player.getItemOnCursor());
    }

    private boolean isCore(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) return false;
        var meta = item.getItemMeta();
        var data = meta.getPersistentDataContainer();
        if (rule.matches(data.get(itemIdKey, PersistentDataType.STRING))) return true;
        for (NamespacedKey key : data.getKeys())
            if (key.getNamespace().equals("buffeditems") && rule.matches(data.get(key, PersistentDataType.STRING))) return true;
        if (item.getType() != Material.HEAVY_CORE || meta.displayName() == null || meta.lore() == null || meta.lore().isEmpty()) return false;
        String display = PlainTextComponentSerializer.plainText().serialize(meta.displayName()).toLowerCase(Locale.ROOT);
        return coreDisplayNames.contains(display);
    }
}
