package net.macecorepickup;

import java.util.Collection;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

/** The inventory rule is independent of the craft ledger and CoreLimiter ownership. */
final class CorePickupRule {
    private final Set<String> coreIds;

    CorePickupRule(Collection<String> coreIds) {
        if (coreIds == null || coreIds.isEmpty() || coreIds.stream().anyMatch(id -> id == null || !id.matches("[A-Za-z0-9_]+")))
            throw new IllegalArgumentException("core-ids must contain valid BuffedItems IDs");
        this.coreIds = coreIds.stream()
                .map(id -> id.toLowerCase(Locale.ROOT)).collect(Collectors.toUnmodifiableSet());
    }

    boolean matches(String buffedItemId) {
        return buffedItemId != null && coreIds.contains(buffedItemId.toLowerCase(Locale.ROOT));
    }

    static boolean blocksPickup(boolean groundMace, boolean groundCore, boolean carriesCore, boolean carriesMace) {
        return groundMace && carriesCore || groundCore && carriesMace;
    }

}
