# HeartCraftGuard

[Download HeartCraftGuard 1.0.1](https://github.com/Bernd502/zoom-updates/raw/refs/heads/main/plugins/HeartCraftGuard-1.0.1.jar)

A separate Paper 1.21.11 plugin for LifeStealZ. A LifeStealZ heart can be an ingredient only when the resulting item is named **Heart Egg** (including colored text, case, separators such as `Heart-Egg`, and plural `Heart Eggs`). This exception applies to player crafting, the automatic Crafter, smithing, and grindstone results. Other recipes using the heart remain blocked. Crafting a LifeStealZ heart from ordinary ingredients and using the heart normally remain allowed.

The input check uses LifeStealZ's own `lifestealz:customitemtype=heart` item-data marker, rather than its display name or material. The Heart Egg exception checks the output item's visible display or item name. Renaming a heart in a vanilla anvil normally preserves that marker, so a plain rename stays available. Anvil combinations or results that lose the marker are blocked. Ordinary items renamed “Heart” are unaffected.

## Install

1. Stop the Paper server. Put `HeartCraftGuard-1.0.1.jar` in its `plugins` folder alongside LifeStealZ. This plugin requires LifeStealZ and does not replace it.
2. Start the server. Check that **HeartCraftGuard** enables in the console or `/plugins`.
3. Try a LifeStealZ heart as a crafting ingredient in a 2×2 grid and crafting table, then in an automatic Crafter. An ordinary output should stay empty or the craft should be cancelled. A Heart Egg result should succeed. Try crafting the heart's own recipe from ordinary ingredients; that should still work.
4. Rename a heart in an anvil and retry the crafting test. A safe rename may succeed, but the renamed heart still cannot be used as an ingredient.

This plugin guards standard Paper crafting and workstation events. A separate plugin that consumes items in a custom GUI without firing those events needs its own integration.

## Build

Requires JDK 21. Run `./gradlew clean build`; the JAR is created in `build/libs/`.
