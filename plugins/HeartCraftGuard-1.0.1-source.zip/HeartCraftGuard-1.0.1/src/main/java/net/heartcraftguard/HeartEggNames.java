package net.heartcraftguard;

import java.text.Normalizer;
import java.util.Locale;
import java.util.regex.Pattern;

/** Matches visible Heart Egg names, including colors, separators, and plural names. */
final class HeartEggNames {
    private static final Pattern LEGACY_COLOR = Pattern.compile("(?i)§[0-9a-fk-orx]");
    private static final Pattern HEART_EGG = Pattern.compile("(?<![a-z0-9])heart\\s*eggs?(?![a-z0-9])");

    private HeartEggNames() { }

    static boolean matches(String name) {
        if (name == null || name.isBlank()) return false;
        String plain = LEGACY_COLOR.matcher(Normalizer.normalize(name, Normalizer.Form.NFKC)).replaceAll("")
                .toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", " ").trim();
        return HEART_EGG.matcher(plain).find();
    }
}
