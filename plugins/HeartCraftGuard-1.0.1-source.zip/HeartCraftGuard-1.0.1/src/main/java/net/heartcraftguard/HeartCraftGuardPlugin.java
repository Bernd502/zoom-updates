package net.heartcraftguard;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Crafter;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.CrafterCraftEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.inventory.PrepareGrindstoneEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.inventory.PrepareSmithingEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.AnvilInventory;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Allows marked LifeStealZ hearts as inputs only for Heart Egg results. */
public final class HeartCraftGuardPlugin extends JavaPlugin implements Listener {
    private static final NamespacedKey HEART_TYPE = new NamespacedKey("lifestealz", "customitemtype");
    private final Map<UUID, Long> lastNotice = new HashMap<>();

    @Override public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);
    }

    static boolean isHeart(ItemStack item) {
        return item != null && !item.getType().isAir() && item.hasItemMeta()
                && "heart".equalsIgnoreCase(item.getItemMeta().getPersistentDataContainer()
                .get(HEART_TYPE, PersistentDataType.STRING));
    }

    private static boolean isHeartEggResult(ItemStack result) {
        if (result == null || result.getType().isAir() || !result.hasItemMeta()) return false;
        var meta = result.getItemMeta();
        if (meta.hasDisplayName())
            return HeartEggNames.matches(PlainTextComponentSerializer.plainText().serialize(meta.displayName()));
        return meta.hasItemName()
                && HeartEggNames.matches(PlainTextComponentSerializer.plainText().serialize(meta.itemName()));
    }

    private static boolean hasHeart(ItemStack[] items) {
        for (ItemStack item : items) if (isHeart(item)) return true;
        return false;
    }

    private static boolean hasHeartInput(Inventory inventory, int resultSlot) {
        for (int slot = 0; slot < inventory.getSize(); slot++)
            if (slot != resultSlot && isHeart(inventory.getItem(slot))) return true;
        return false;
    }

    private static boolean unsafeAnvil(AnvilInventory inventory, ItemStack result) {
        ItemStack first = inventory.getFirstItem(), second = inventory.getSecondItem();
        if (!isHeart(first) && !isHeart(second)) return false;
        // A plain rename is safe only when the original heart marker survives.
        return !isHeart(first) || second != null && !second.getType().isAir() || !isHeart(result);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPrepareCraft(PrepareItemCraftEvent event) {
        if (hasHeart(event.getInventory().getMatrix()) && !isHeartEggResult(event.getInventory().getResult()))
            event.getInventory().setResult(null);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCraft(CraftItemEvent event) {
        if (hasHeart(event.getInventory().getMatrix()) && !isHeartEggResult(event.getCurrentItem())) {
            event.setCancelled(true);
            notice(event.getWhoClicked());
        }
    }

    /** Final click guard covers shift-clicks and other result-based workstations. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onResultClick(InventoryClickEvent event) {
        if (event.getSlotType() != InventoryType.SlotType.RESULT || event.getRawSlot() < 0
                || event.getRawSlot() >= event.getView().getTopInventory().getSize()) return;
        Inventory top = event.getView().getTopInventory();
        if (top instanceof AnvilInventory anvil) {
            if (unsafeAnvil(anvil, event.getCurrentItem())) {
                event.setCancelled(true);
                notice(event.getWhoClicked());
            }
            return;
        }
        if (!hasHeartInput(top, event.getRawSlot()) || isHeartEggResult(event.getCurrentItem())) return;
        event.setCancelled(true);
        notice(event.getWhoClicked());
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPrepareSmithing(PrepareSmithingEvent event) {
        var inventory = event.getInventory();
        if ((isHeart(inventory.getInputTemplate()) || isHeart(inventory.getInputEquipment())
                || isHeart(inventory.getInputMineral())) && !isHeartEggResult(event.getResult()))
            event.setResult(null);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPrepareGrindstone(PrepareGrindstoneEvent event) {
        if ((isHeart(event.getInventory().getItem(0)) || isHeart(event.getInventory().getItem(1)))
                && !isHeartEggResult(event.getResult())) event.setResult(null);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPrepareAnvil(PrepareAnvilEvent event) {
        if (unsafeAnvil(event.getInventory(), event.getResult())) event.setResult(null);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCrafterCraft(CrafterCraftEvent event) {
        if (event.getBlock().getState(false) instanceof Crafter crafter
                && hasHeart(crafter.getInventory().getContents()) && !isHeartEggResult(event.getResult()))
            event.setCancelled(true);
    }

    private void notice(org.bukkit.entity.HumanEntity entity) {
        if (!(entity instanceof Player player)) return;
        long now = System.currentTimeMillis();
        long last = lastNotice.getOrDefault(player.getUniqueId(), 0L);
        if (now - last < 2000) return;
        lastNotice.put(player.getUniqueId(), now);
        player.sendMessage(ChatColor.RED + "LifeStealZ hearts can only craft Heart Egg items.");
    }
}
