package net.heartcraftguard;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HeartEggNamesTest {
    @Test void acceptsHeartEggVariants() {
        for (String name : new String[]{"Heart Egg", "heart egg", "HEART-EGG", "Heart_Egg",
                "HeartEgg", "Heart Eggs", "§cHeart Egg", "✦ Heart Egg ✦", "Rare Heart Egg (Level II)"})
            assertTrue(HeartEggNames.matches(name), name);
    }

    @Test void rejectsOtherRecipesAndLookalikes() {
        for (String name : new String[]{null, "", "Heart", "Egg", "Heart Sword", "Dragon Egg",
                "Heart Eggplant", "Sweetheart Egg", "Heart Egger"})
            assertFalse(HeartEggNames.matches(name), String.valueOf(name));
    }
}
