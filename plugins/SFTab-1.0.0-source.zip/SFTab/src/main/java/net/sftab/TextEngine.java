package net.sftab;

import java.util.*;
import java.util.regex.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;

final class TextEngine {
    private static final MiniMessage MM=MiniMessage.miniMessage();
    private static final Pattern ANIMATION=Pattern.compile("\\{animation:([a-zA-Z0-9_-]+)}");
    private static final Pattern TOKEN=Pattern.compile("\\{([a-z_]+)}");
    static String animate(String text, Map<String,List<String>> animations,long frame) {
        // Frames can contain normal tokens; nested animation references remain literal.
        var m=ANIMATION.matcher(text);var out=new StringBuilder();
        while(m.find()){
            var frames=animations.get(m.group(1));
            String value=frames==null||frames.isEmpty()?m.group():frames.get((int)Math.floorMod(frame,frames.size()));
            m.appendReplacement(out,Matcher.quoteReplacement(value));
        }
        return m.appendTail(out).toString();
    }
    static String tokens(String text,Map<String,String> values,Map<String,String> formatted){
        var m=TOKEN.matcher(text);var out=new StringBuilder();
        while(m.find()){
            String key=m.group(1), value=formatted.containsKey(key)?formatted.get(key):values.containsKey(key)?MM.escapeTags(values.get(key)):m.group();
            m.appendReplacement(out,Matcher.quoteReplacement(value));
        }
        return m.appendTail(out).toString();
    }
    static Component parse(String text){return MM.deserialize(text);}
    static String formatted(Component component){return MM.serialize(component);}
    static Comparator<Entry> order(String mode,List<String> groups,boolean descending){
        Comparator<Entry> byName=Comparator.comparing(Entry::name,String.CASE_INSENSITIVE_ORDER).thenComparing(Entry::id);
        Comparator<Entry> primary=switch(mode){
            case "group"->Comparator.comparingInt(e->{int index=groups.indexOf(e.group().toLowerCase(Locale.ROOT));return index<0?groups.size():index;});
            case "ping"->Comparator.comparingInt(Entry::ping);
            case "world"->Comparator.comparing(Entry::world,String.CASE_INSENSITIVE_ORDER);
            default->byName;
        };
        var result=primary.thenComparing(byName);return descending?result.reversed():result;
    }
    record Entry(UUID id,String name,String group,int ping,String world){}
}
