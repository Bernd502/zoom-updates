package net.sftab;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import java.lang.reflect.Method;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

final class Hooks {
    record Meta(String prefix,String suffix,String group){}
    static Meta meta(Player p){
        if(Bukkit.getPluginManager().isPluginEnabled("LuckPerms"))try{return LuckPermsHook.meta(p);}catch(LinkageError|RuntimeException ignored){}
        return new Meta("","","default");
    }
    private static final class LuckPermsHook {
        static Meta meta(Player p){
            var api=net.luckperms.api.LuckPermsProvider.get();
            var adapter=api.getPlayerAdapter(Player.class);var data=adapter.getMetaData(p);
            return new Meta(format(data.getPrefix()),format(data.getSuffix()),adapter.getUser(p).getPrimaryGroup());
        }
        private static String format(String s){
            if(s==null)return "";
            // LuckPerms commonly uses legacy & colors; MiniMessage prefixes also work.
            return s.indexOf('&')>=0||s.indexOf('§')>=0?TextEngine.formatted(LegacyComponentSerializer.legacySection().deserialize(s.replace('&','§'))):s;
        }
    }
    private Method papi;
    Hooks(){
        if(Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI"))try{
            papi=Class.forName("me.clip.placeholderapi.PlaceholderAPI").getMethod("setPlaceholders",org.bukkit.OfflinePlayer.class,String.class);
        }catch(ReflectiveOperationException ignored){}
    }
    String placeholders(Player p,String text){
        if(papi==null||text.indexOf('%')<0)return text;
        try{return (String)papi.invoke(null,p,text);}catch(ReflectiveOperationException ex){return text;}
    }
}
