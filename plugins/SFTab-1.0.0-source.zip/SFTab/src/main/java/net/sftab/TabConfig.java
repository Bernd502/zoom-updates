package net.sftab;

import java.util.*;
import org.bukkit.configuration.ConfigurationSection;

record TabConfig(boolean enabled, int refreshTicks, Set<String> disabledWorlds, Layout base,
                 Map<String, Layout> worlds, String serverName, String website,
                 Map<String,String> groupFormats, boolean sorting, String sortMode,
                 boolean descending, List<String> groups, Map<String,List<String>> animations) {
    record Layout(List<String> header, List<String> footer, String name) {}
    Layout layout(String world) { return worlds.getOrDefault(world, base); }
    static TabConfig parse(ConfigurationSection c) {
        Object rawTicks=c.get("refresh-ticks",20);
        if(!(rawTicks instanceof Number number)||number.doubleValue()!=number.intValue())throw new IllegalArgumentException("refresh-ticks must be an integer");
        int ticks=number.intValue();
        if (ticks < 2 || ticks > 1200) throw new IllegalArgumentException("refresh-ticks must be 2..1200");
        var base = new Layout(lines(c,"header",List.of()), lines(c,"footer",List.of()),text(c,"player-name","<white>{player}</white>"));
        var worlds = new HashMap<String,Layout>();
        var ws = c.getConfigurationSection("worlds");
        if (ws != null) for (String world : ws.getKeys(false)) {
            var w = ws.getConfigurationSection(world);
            if (w == null) throw new IllegalArgumentException("worlds." + world + " must be a section");
            worlds.put(world,new Layout(lines(w,"header",base.header),lines(w,"footer",base.footer),text(w,"player-name",base.name)));
        }
        var animations = new HashMap<String,List<String>>();
        var as = c.getConfigurationSection("animations");
        if (as != null) for (String key : as.getKeys(false)) {
            var frames=lines(as,key,List.of());
            if (frames.isEmpty()) throw new IllegalArgumentException("Animation " + key + " needs at least one frame");
            animations.put(key,frames);
        }
        String mode=text(c,"sorting.mode","group").toLowerCase(Locale.ROOT);
        if (!Set.of("group","name","ping","world","none").contains(mode)) throw new IllegalArgumentException("Unknown sorting.mode: "+mode);
        var groups=lines(c,"sorting.groups",List.of("default")).stream().map(s->s.toLowerCase(Locale.ROOT)).toList();
        var formats=new HashMap<String,String>();
        var fs=c.getConfigurationSection("group-formats");
        if(fs!=null)for(String key:fs.getKeys(false))formats.put(key.toLowerCase(Locale.ROOT),text(fs,key,base.name));
        return new TabConfig(bool(c,"enabled",true),ticks,Set.copyOf(lines(c,"disabled-worlds",List.of())),base,Map.copyOf(worlds),
                text(c,"server-name","Your Server"),text(c,"website","example.com"),Map.copyOf(formats),bool(c,"sorting.enabled",true),mode,bool(c,"sorting.descending",false),groups,Map.copyOf(animations));
    }
    private static boolean bool(ConfigurationSection c,String key,boolean fallback){
        if(!c.contains(key))return fallback;
        if(!(c.get(key) instanceof Boolean b))throw new IllegalArgumentException(key+" must be true or false");return b;
    }
    private static String text(ConfigurationSection c,String key,String fallback) {
        if (!c.contains(key)) return fallback;
        if (!(c.get(key) instanceof String s) || s.length()>4096) throw new IllegalArgumentException(key+" must be text up to 4096 characters");
        return s;
    }
    private static List<String> lines(ConfigurationSection c,String key,List<String> fallback) {
        if (!c.contains(key)) return fallback;
        Object raw=c.get(key);
        if (!(raw instanceof List<?> list) || list.size()>100) throw new IllegalArgumentException(key+" must be a list with at most 100 lines");
        var out=new ArrayList<String>();
        for(Object item:list){if(!(item instanceof String s)||s.length()>4096)throw new IllegalArgumentException(key+" must contain text up to 4096 characters");out.add(s);}
        return List.copyOf(out);
    }
}
