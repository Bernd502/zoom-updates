package net.sftab;

import net.kyori.adventure.text.Component;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import java.io.*;
import java.nio.file.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public final class SFTabPlugin extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {
    private TabConfig settings;
    private YamlConfiguration yaml;
    private Hooks hooks;
    private Editor editor;
    private BukkitTask timer;
    private long frame, lastError;
    private final Set<UUID> hidden=new HashSet<>();
    private record Original(Component header,Component footer,Component name,int order){}
    private final Map<UUID,Original> original=new HashMap<>();
    @Override public void onEnable(){
        saveDefaultConfig();hooks=new Hooks();editor=new Editor(this);
        Bukkit.getPluginManager().registerEvents(this,this);Bukkit.getPluginManager().registerEvents(editor,this);
        Objects.requireNonNull(getCommand("sftab")).setExecutor(this);
        Objects.requireNonNull(getCommand("sftab")).setTabCompleter(this);
        try{load();}catch(Exception ex){getLogger().severe("Cannot load config.yml: "+ex.getMessage());Bukkit.getPluginManager().disablePlugin(this);}
    }
    @Override public void onDisable(){if(timer!=null)timer.cancel();restoreAll();if(editor!=null)editor.close();}
    TabConfig settings(){return settings;}
    YamlConfiguration yaml(){return yaml;}
    void load() throws Exception {
        var candidate=new YamlConfiguration();candidate.load(new File(getDataFolder(),"config.yml"));
        var parsed=TabConfig.parse(candidate);commit(candidate,parsed);
    }
    void change(String key,Object value) throws Exception {
        var candidate=new YamlConfiguration();candidate.loadFromString(yaml.saveToString());if(value instanceof Map<?,?> map){candidate.set(key,null);candidate.createSection(key,map);}else candidate.set(key,value);
        var parsed=TabConfig.parse(candidate);
        Path dest=getDataFolder().toPath().resolve("config.yml"),temp=Files.createTempFile(getDataFolder().toPath(),"config-",".tmp");
        try{candidate.save(temp.toFile());try{Files.move(temp,dest,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}catch(AtomicMoveNotSupportedException ex){Files.move(temp,dest,StandardCopyOption.REPLACE_EXISTING);}}
        finally{Files.deleteIfExists(temp);}
        commit(candidate,parsed);
    }
    private void commit(YamlConfiguration candidate,TabConfig parsed){
        if(timer!=null)timer.cancel();restoreAll();yaml=candidate;settings=parsed;frame=0;
        timer=Bukkit.getScheduler().runTaskTimer(this,this::refresh,1,settings.refreshTicks());
    }
    private void refresh(){
        if(!settings.enabled()){restoreAll();return;}
        var active=new ArrayList<Player>();var metas=new HashMap<UUID,Hooks.Meta>();
        for(Player p:Bukkit.getOnlinePlayers()){
            if(settings.disabledWorlds().contains(p.getWorld().getName())){restore(p);continue;}
            original.computeIfAbsent(p.getUniqueId(),id->new Original(p.playerListHeader(),p.playerListFooter(),p.playerListName(),p.getPlayerListOrder()));
            var meta=Hooks.meta(p);metas.put(p.getUniqueId(),meta);active.add(p);
            try{
                var layout=settings.layout(p.getWorld().getName());
                var name=render(p,settings.groupFormats().getOrDefault(meta.group().toLowerCase(Locale.ROOT),layout.name()),meta);
                if(!name.equals(p.playerListName()))p.playerListName(name);
                var before=original.get(p.getUniqueId());
                Component header=hidden.contains(p.getUniqueId())?before.header():render(p,String.join("\n",layout.header()),meta);
                Component footer=hidden.contains(p.getUniqueId())?before.footer():render(p,String.join("\n",layout.footer()),meta);
                if(!Objects.equals(header,p.playerListHeader())||!Objects.equals(footer,p.playerListFooter()))p.sendPlayerListHeaderAndFooter(header==null?Component.empty():header,footer==null?Component.empty():footer);
            }catch(RuntimeException ex){if(System.currentTimeMillis()-lastError>60000){lastError=System.currentTimeMillis();getLogger().warning("Tab rendering failed: "+ex.getClass().getSimpleName()+". Check text and PlaceholderAPI expansions.");}}
        }
        if(settings.sorting()&&!settings.sortMode().equals("none")){
            var comparator=TextEngine.order(settings.sortMode(),settings.groups(),settings.descending());
            active.sort((a,b)->comparator.compare(entry(a,metas),entry(b,metas)));
            // Minecraft renders higher list-order values first.
            for(int i=0;i<active.size();i++){var p=active.get(i);int order=active.size()-i;if(p.getPlayerListOrder()!=order)p.setPlayerListOrder(order);}
        }else for(Player p:active){int order=original.get(p.getUniqueId()).order();if(p.getPlayerListOrder()!=order)p.setPlayerListOrder(order);}
        frame++;
    }
    private TextEngine.Entry entry(Player p,Map<UUID,Hooks.Meta> metas){return new TextEngine.Entry(p.getUniqueId(),p.getName(),metas.get(p.getUniqueId()).group(),p.getPing(),p.getWorld().getName());}
    private Component render(Player p,String template,Hooks.Meta meta){
        var values=new HashMap<String,String>();
        values.put("player",p.getName());values.put("display_name",net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText().serialize(p.displayName()));
        values.put("uuid",p.getUniqueId().toString());values.put("group",meta.group());values.put("server",settings.serverName());values.put("website",settings.website());
        values.put("online",String.valueOf(Bukkit.getOnlinePlayers().stream().filter(p::canSee).count()));values.put("max_players",String.valueOf(Bukkit.getMaxPlayers()));
        values.put("ping",String.valueOf(p.getPing()));values.put("world",p.getWorld().getName());values.put("health",String.format(Locale.ROOT,"%.0f",p.getHealth()));
        values.put("hearts",String.format(Locale.ROOT,"%.1f",p.getHealth()/2));values.put("level",String.valueOf(p.getLevel()));
        values.put("tps",String.format(Locale.ROOT,"%.1f",Math.min(20,Bukkit.getTPS()[0])));
        values.put("date",LocalDate.now().format(DateTimeFormatter.ISO_DATE));values.put("time",LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")));
        String animated=TextEngine.animate(template,settings.animations(),frame);
        String text=TextEngine.tokens(animated,values,Map.of("prefix",meta.prefix(),"suffix",meta.suffix()));
        return TextEngine.parse(hooks.placeholders(p,text));
    }
    private void restore(Player p){
        var old=original.remove(p.getUniqueId());if(old==null)return;
        p.sendPlayerListHeaderAndFooter(old.header()==null?Component.empty():old.header(),old.footer()==null?Component.empty():old.footer());
        p.playerListName(old.name());p.setPlayerListOrder(old.order());
    }
    private void restoreAll(){for(Player p:Bukkit.getOnlinePlayers())restore(p);original.clear();}
    @EventHandler public void quit(PlayerQuitEvent e){original.remove(e.getPlayer().getUniqueId());hidden.remove(e.getPlayer().getUniqueId());editor.forget(e.getPlayer());}
    void message(CommandSender sender,String text){sender.sendMessage(Component.text("[SFTab] "+text));}
    @Override public boolean onCommand(CommandSender sender,Command command,String label,String[] args){
        String sub=args.length==0?"edit":args[0].toLowerCase(Locale.ROOT);
        if(sub.equals("toggle")){
            if(!(sender instanceof Player p)){message(sender,"Players only.");return true;}
            if(!p.hasPermission("sftab.toggle")){message(p,"You do not have permission.");return true;}
            if(!hidden.add(p.getUniqueId()))hidden.remove(p.getUniqueId());refresh();message(p,hidden.contains(p.getUniqueId())?"Custom header/footer hidden for you until you toggle again or reconnect.":"Custom header/footer shown.");return true;
        }
        if(!sender.hasPermission("sftab.admin")){message(sender,"You need sftab.admin to edit the player list.");return true;}
        try{switch(sub){
            case "edit","gui"->{if(sender instanceof Player p)editor.home(p);else message(sender,"Use /sftab reload, status, on, off or set from console.");}
            case "reload"->{load();message(sender,"Reloaded config.yml.");}
            case "on","off"->{change("enabled",sub.equals("on"));message(sender,"Tab styling "+sub+".");}
            case "status"->message(sender,"v"+getPluginMeta().getVersion()+" | "+(settings.enabled()?"ON":"OFF")+" | refresh "+settings.refreshTicks()+" ticks | sorting "+settings.sortMode()+" | "+settings.worlds().size()+" world layouts | LuckPerms "+Bukkit.getPluginManager().isPluginEnabled("LuckPerms")+" | PlaceholderAPI "+Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI"));
            case "cancel"->{if(sender instanceof Player p){editor.forget(p);message(p,"Edit cancelled.");}}
            case "set"->set(sender,args);
            default->message(sender,"/sftab edit | reload | on | off | status | toggle | cancel | set");
        }}catch(Exception ex){message(sender,"Could not apply change: "+ex.getMessage()+". Previous settings remain active.");}
        return true;
    }
    private void set(CommandSender sender,String[] args) throws Exception {
        if(args.length<3)throw new IllegalArgumentException("Use /sftab set <server-name|website|player-name|refresh-ticks> <value>, or set <header|footer> <line> <text>");
        String key=args[1];
        if(key.equals("header")||key.equals("footer")){
            if(args.length<4)throw new IllegalArgumentException("Specify a line number and text");
            var lines=new ArrayList<>(yaml.getStringList(key));int line=Integer.parseInt(args[2])-1;
            if(line<0||line>lines.size())throw new IllegalArgumentException("Line must be 1.."+(lines.size()+1));
            String value=String.join(" ",Arrays.copyOfRange(args,3,args.length));if(line==lines.size())lines.add(value);else lines.set(line,value);change(key,lines);
        }else{
            if(!Set.of("server-name","website","player-name","refresh-ticks").contains(key))throw new IllegalArgumentException("Unknown editable field");
            String value=String.join(" ",Arrays.copyOfRange(args,2,args.length));change(key,key.equals("refresh-ticks")?Integer.parseInt(value):value);
        }
        message(sender,"Saved "+key+" and applied immediately.");
    }
    @Override public List<String> onTabComplete(CommandSender sender,Command cmd,String alias,String[] args){
        List<String> choices=args.length==1?(sender.hasPermission("sftab.admin")?List.of("edit","reload","on","off","status","toggle","cancel","set"):List.of("toggle")):args.length==2&&args[0].equalsIgnoreCase("set")&&sender.hasPermission("sftab.admin")?List.of("server-name","website","player-name","refresh-ticks","header","footer"):List.of();
        String prefix=args[args.length-1].toLowerCase(Locale.ROOT);return choices.stream().filter(s->s.startsWith(prefix)).toList();
    }
}
