package net.sftab;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

final class Editor implements Listener {
    private final SFTabPlugin plugin;
    private final Map<UUID,Edit> edits=new ConcurrentHashMap<>();
    private record Edit(String path,String parent,int index,boolean addKey){}
    private static final class Menu implements InventoryHolder {
        Inventory inventory;final Map<Integer,Consumer<InventoryClickEvent>> actions=new HashMap<>();
        @Override public Inventory getInventory(){return inventory;}
    }
    Editor(SFTabPlugin plugin){this.plugin=plugin;}
    void forget(Player p){edits.remove(p.getUniqueId());}
    void close(){edits.clear();for(var p:Bukkit.getOnlinePlayers())if(p.getOpenInventory().getTopInventory().getHolder() instanceof Menu)p.closeInventory();}
    void home(Player p){browse(p,"",0);}
    private void browse(Player p,String path,int page){
        Menu menu=new Menu();menu.inventory=Bukkit.createInventory(menu,54,Component.text("SFTab • "+(path.isEmpty()?"Settings":path)));
        var yaml=plugin.yaml();Object raw=path.isEmpty()?yaml:yaml.get(path);
        List<String> keys;
        if(raw instanceof org.bukkit.configuration.ConfigurationSection section)keys=new ArrayList<>(section.getKeys(false));
        else if(raw instanceof List<?> list){keys=new ArrayList<>();for(int i=0;i<list.size();i++)keys.add(String.valueOf(i));}
        else {home(p);return;}
        int start=Math.max(0,page)*45;
        for(int slot=0;slot<45&&start+slot<keys.size();slot++){
            String key=keys.get(start+slot);int index=raw instanceof List<?>?Integer.parseInt(key):-1;
            String child=index>=0?path:path.isEmpty()?key:path+"."+key;
            Object value=index>=0?((List<?>)raw).get(index):yaml.get(child);
            boolean container=value instanceof List<?>||value instanceof org.bukkit.configuration.ConfigurationSection;
            String preview=container?"Click to open":String.valueOf(value);
            put(menu,slot,value instanceof Boolean?Material.LEVER:container?Material.CHEST:Material.NAME_TAG,
                index>=0?"Line "+(index+1):key,List.of(preview,"Click to "+(value instanceof Boolean?"toggle":container?"browse":"edit"),"Shift + right-click: remove line/custom entry"),event->{
                    if(event.isShiftClick()&&event.isRightClick()&&(index>=0||Set.of("worlds","animations","group-formats").contains(path))){
                        try{if(index>=0){var list=new ArrayList<>(plugin.yaml().getList(path,List.of()));list.remove(index);plugin.change(path,list);}else plugin.change(child,null);browse(p,path,page);}catch(Exception ex){plugin.message(p,ex.getMessage());}return;
                    }
                    if(container){browse(p,child,0);return;}
                    if(value instanceof Boolean b){try{plugin.change(child,!b);browse(p,path,page);}catch(Exception ex){plugin.message(p,ex.getMessage());}return;}
                    prompt(p,new Edit(child,path,index,false),"Enter a new value for "+(index>=0?"line "+(index+1):child)+". Type cancel to cancel or <empty> for a blank line.");
                });
        }
        if(start>0)put(menu,45,Material.ARROW,"Previous page",List.of(),e->browse(p,path,page-1));
        put(menu,46,Material.OAK_DOOR,"Back",List.of(),e->browse(p,parent(path),0));
        if(raw instanceof List<?>)put(menu,49,Material.EMERALD,"Add line",List.of("Enter text in chat."),e->prompt(p,new Edit(path,path,-2,false),"Enter the new line. Use <empty> for a blank line or cancel to cancel."));
        else if(Set.of("worlds","animations","group-formats").contains(path))put(menu,49,Material.EMERALD,"Add entry",List.of("World name, animation ID, or LuckPerms group."),e->prompt(p,new Edit(path,path,-1,true),"Enter the new "+path+" key (letters, digits, underscores or hyphens), or cancel."));
        put(menu,51,Material.BOOK,"Text and placeholders",List.of("MiniMessage: <aqua>text</aqua>","{player}, {ping}, {online}, {hearts}","{server}, {website}, {world}, {tps}","{prefix}, {suffix}, {group}","{animation:welcome}, %PAPI_placeholder%","All edits save and apply immediately."),e->{});
        if(start+45<keys.size())put(menu,53,Material.ARROW,"Next page",List.of(),e->browse(p,path,page+1));
        p.openInventory(menu.inventory);
    }
    private String parent(String path){int dot=path.lastIndexOf('.');return dot<0?"":path.substring(0,dot);}
    private void prompt(Player p,Edit edit,String message){edits.put(p.getUniqueId(),edit);p.closeInventory();plugin.message(p,message);}
    private void put(Menu menu,int slot,Material material,String name,List<String> lore,Consumer<InventoryClickEvent> action){
        var item=new ItemStack(material);ItemMeta meta=item.getItemMeta();meta.displayName(Component.text(name));
        meta.lore(lore.stream().map(s->Component.text(s.length()>180?s.substring(0,180)+"…":s)).toList());item.setItemMeta(meta);menu.inventory.setItem(slot,item);menu.actions.put(slot,action);
    }
    @EventHandler public void click(InventoryClickEvent e){
        if(!(e.getView().getTopInventory().getHolder() instanceof Menu menu))return;
        e.setCancelled(true);
        if(!(e.getWhoClicked() instanceof Player p)||!p.hasPermission("sftab.admin"))return;
        var action=menu.actions.get(e.getRawSlot());if(action!=null)Bukkit.getScheduler().runTask(plugin,()->{if(p.isOnline()&&p.hasPermission("sftab.admin"))action.accept(e);});
    }
    @EventHandler public void drag(InventoryDragEvent e){if(e.getView().getTopInventory().getHolder() instanceof Menu)e.setCancelled(true);}
    @EventHandler(priority=EventPriority.LOWEST) public void chat(AsyncChatEvent e){
        var edit=edits.remove(e.getPlayer().getUniqueId());if(edit==null)return;
        e.setCancelled(true);String input=PlainTextComponentSerializer.plainText().serialize(e.message());
        Bukkit.getScheduler().runTask(plugin,()->apply(e.getPlayer(),edit,input));
    }
    private void apply(Player p,Edit edit,String input){
        if(!p.isOnline()||!p.hasPermission("sftab.admin"))return;
        if(input.equalsIgnoreCase("cancel")){plugin.message(p,"Edit cancelled.");browse(p,edit.parent(),0);return;}
        String value=input.equals("<empty>")?"":input;
        try{
            if(edit.addKey()){
                if(!value.matches("[A-Za-z0-9_-]{1,64}"))throw new IllegalArgumentException("Use 1..64 letters, digits, underscores or hyphens");
                String key=edit.path()+"."+value;
                if(plugin.yaml().contains(key))throw new IllegalArgumentException("That entry already exists");
                Object seed=switch(edit.path()){
                    case "worlds"->Map.of("header",plugin.settings().base().header(),"footer",plugin.settings().base().footer(),"player-name",plugin.settings().base().name());
                    case "animations"->List.of("Your first frame");default->"<white>{player}</white>";
                };
                plugin.change(key,seed);
            }else if(edit.index()>=0||edit.index()==-2){
                var lines=new ArrayList<>(plugin.yaml().getStringList(edit.path()));
                if(edit.index()==-2)lines.add(value);else{if(edit.index()>=lines.size())throw new IllegalArgumentException("The line was changed by another editor; reopen the menu");lines.set(edit.index(),value);}
                plugin.change(edit.path(),lines);
            }else{
                Object current=plugin.yaml().get(edit.path());plugin.change(edit.path(),current instanceof Number?Integer.parseInt(value):value);
            }
            plugin.message(p,"Saved and applied.");browse(p,edit.parent(),0);
        }catch(Exception ex){edits.put(p.getUniqueId(),edit);plugin.message(p,"Could not save: "+ex.getMessage()+". Try again or type cancel.");}
    }
}
