package net.sftab;
import org.junit.jupiter.api.Test;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.*;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
class TabConfigTest {
    private YamlConfiguration defaults() throws Exception {
        var y=new YamlConfiguration();
        try(var reader=new InputStreamReader(Objects.requireNonNull(getClass().getResourceAsStream("/config.yml")),java.nio.charset.StandardCharsets.UTF_8)){y.load(reader);}
        return y;
    }
    @Test void shippedConfigHasWorkingDefaultLayout() throws Exception {
        var c=TabConfig.parse(defaults());assertTrue(c.enabled());assertEquals(20,c.refreshTicks());assertEquals(c.base(),c.layout("unknown"));assertFalse(c.base().header().isEmpty());assertFalse(c.animations().get("welcome").isEmpty());
    }
    @Test void worldOverridesInheritOmittedFields() throws Exception {
        var y=defaults();y.createSection("worlds.arena");y.set("worlds.arena.header",List.of("<red>Arena</red>"));
        var c=TabConfig.parse(y);assertEquals(List.of("<red>Arena</red>"),c.layout("arena").header());assertEquals(c.base().footer(),c.layout("arena").footer());assertEquals(c.base().name(),c.layout("arena").name());
    }
    @Test void rejectsWrongTypesAndUnsafeRefreshRates() throws Exception {
        for(Object value:List.of(0,1,1201,"fast",20.5)){
            var y=defaults();y.set("refresh-ticks",value);assertThrows(IllegalArgumentException.class,()->TabConfig.parse(y));
        }
        var y=defaults();y.set("enabled","yes");assertThrows(IllegalArgumentException.class,()->TabConfig.parse(y));
    }
    @Test void rejectsInvalidListsModesAndEmptyAnimations() throws Exception {
        var y=defaults();y.set("header","wrong type");final var badHeader=y;assertThrows(IllegalArgumentException.class,()->TabConfig.parse(badHeader));
        y=defaults();y.set("sorting.mode","mystery");final var badSort=y;assertThrows(IllegalArgumentException.class,()->TabConfig.parse(badSort));
        y=defaults();y.set("animations.welcome",List.of());final var badFrames=y;assertThrows(IllegalArgumentException.class,()->TabConfig.parse(badFrames));
    }
    @Test void snapshotsAreImmutableAndIndependentOfYamlEdits() throws Exception {
        var y=defaults();var c=TabConfig.parse(y);y.set("header",List.of("changed"));
        assertNotEquals(List.of("changed"),c.base().header());assertThrows(UnsupportedOperationException.class,()->c.base().header().add("x"));
    }
}
