package net.sftab;
import org.junit.jupiter.api.Test;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
class TextEngineTest {
    @Test void playerSuppliedValuesCannotInjectFormattingOrOtherTokens(){
        var result=TextEngine.tokens("<gray>{player}</gray>",Map.of("player","<red>{ping}" ,"ping","123"),Map.of());
        assertEquals("<red>{ping}",PlainTextComponentSerializer.plainText().serialize(TextEngine.parse(result)));
    }
    @Test void intentionalRankFormattingWorksAndUnknownTokensStayVisible(){
        var text=TextEngine.tokens("{prefix}{player} {unknown}",Map.of("player","Alex"),Map.of("prefix","<gold>[VIP]</gold> "));
        assertEquals("[VIP] Alex {unknown}",PlainTextComponentSerializer.plainText().serialize(TextEngine.parse(text)));
    }
    @Test void animationCyclesWithoutRecursionOrReplacementSyntaxInterpretation(){
        var frames=Map.of("welcome",List.of("$1 \\ hello {player}","second"));
        assertEquals("second",TextEngine.animate("{animation:welcome}",frames,1));
        assertEquals("$1 \\ hello {player}",TextEngine.animate("{animation:welcome}",frames,2));
        assertEquals("{animation:missing}",TextEngine.animate("{animation:missing}",frames,0));
        assertEquals("{animation:a}",TextEngine.animate("{animation:a}",Map.of("a",List.of("{animation:a}")),0));
    }
    private TextEngine.Entry entry(String name,String group,int ping){return new TextEngine.Entry(UUID.nameUUIDFromBytes(name.getBytes()),name,group,ping,"world");}
    @Test void groupsSortInConfiguredOrderThenAlphabeticallyWithUnknownGroupsLast(){
        var list=new ArrayList<>(List.of(entry("Zoe","vip",30),entry("Ben","unknown",20),entry("Alex","vip",40),entry("Owner","owner",80)));
        list.sort(TextEngine.order("group",List.of("owner","vip"),false));
        assertEquals(List.of("Owner","Alex","Zoe","Ben"),list.stream().map(TextEngine.Entry::name).toList());
    }
    @Test void pingAndDescendingSortingAreDeterministic(){
        var list=new ArrayList<>(List.of(entry("Zoe","vip",30),entry("Alex","vip",30),entry("Owner","owner",80)));
        list.sort(TextEngine.order("ping",List.of(),false));assertEquals(List.of("Alex","Zoe","Owner"),list.stream().map(TextEngine.Entry::name).toList());
        list.sort(TextEngine.order("ping",List.of(),true));assertEquals(List.of("Owner","Zoe","Alex"),list.stream().map(TextEngine.Entry::name).toList());
    }
}
