rootProject.name = "SFTab"
