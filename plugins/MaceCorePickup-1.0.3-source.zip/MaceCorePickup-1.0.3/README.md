# MaceCorePickup

[Download the latest JAR](https://github.com/Bernd502/zoom-updates/raw/refs/heads/main/plugins/MaceCorePickup-1.0.3.jar)

A separate Paper 1.21.11 plugin for the CoreCraftOnce/BuffedItems setup. While protection is ON, non-OP players cannot carry a mace and one of the configured cores together, regardless of which item they pick up first. They also cannot put a mace in a container, bundle, item frame, or armor stand. Hopper transfers and hopper pickup of maces are blocked. OPs bypass player restrictions; the console or an OP can turn protection on or off. Existing stored maces are not automatically removed from unloaded containers.

The plugin first matches BuffedItems' `buffeditems:buffeditem_id` persistent-data value. It also recognizes configured core IDs in other BuffedItems string keys and, as a fallback, the configured display names on custom-lore heavy cores. The ten defaults match the supplied BuffedItems setup. Edit `plugins/MaceCorePickup/config.yml` if your server uses different IDs, names, or item-data keys. `/mcp inspect` reports whether the held item is recognized and shows its BuffedItems string keys to help diagnose mismatches.

Both ground pickup events, container click/drag transfers, entity storage, and hopper movement are checked. Every five ticks, the plugin also resolves a mace/core pair inserted by a command or another plugin: it removes the mace from the non-OP player's inventory and drops it at their location. The item is never deleted. Vanilla player inventory and hotbar are allowed when no core is carried. Admin commands or another plugin can still directly edit storage; this plugin does not scan every unloaded container.

## Install

1. Stop the server. Remove the older MaceCorePickup JAR, then put `MaceCorePickup-1.0.3.jar` in the Paper server's `plugins` folder alongside BuffedItems. Keep CoreCraftOnce if you use it.
2. Restart the server. Run `/mcp status` as an OP or from the console; protection should be ON. Existing `config.yml` settings are retained.
3. As a non-OP, test both orders: carry an Air Core and try to pick up a dropped mace; then carry a mace and try to pick up an Air Core. Test chest, ender chest, bundle, item frame, and hopper storage. Use `/mcp inspect` while holding the core if it is not recognized.

An OP or the console can run `/macecorepickup on`, `off`, `toggle`, or `status`. `/mcp inspect` requires an OP in-game. The short aliases are `/mcp` and `/mcpickup`. For example, use `/mcp status` or `/mcp inspect`. The state is saved to `plugins/MaceCorePickup/config.yml` and survives restarts; it starts ON. Non-OP players cannot use the command even if a permission plugin grants its permission node.

## Build

Requires JDK 21. Run `./gradlew clean test build`. The JAR is created in `build/libs/`.
