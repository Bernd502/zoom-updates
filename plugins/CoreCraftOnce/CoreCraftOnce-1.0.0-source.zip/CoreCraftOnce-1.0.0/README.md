# CoreCraftOnce

Paper 1.21.11 companion plugin for the supplied BuffedItems and CoreLimiter setup. It allows the first successful craft of each configured BuffedItems core on the server, then blocks future crafts of that core. Its ledger survives restarts.

The plugin identifies custom items using BuffedItems' `buffeditems:buffeditem_id` persistent-data key and only limits the ten core IDs from the supplied `items.yml`; unrelated items made from `HEAVY_CORE` are unaffected. Shift-click crafting of a unique core is denied because BuffedItems' shift-click handler can produce several outputs in one action. A normal click can craft the one allowed core.

## Install

1. Copy `CoreCraftOnce-1.0.0.jar` into the Paper server's `plugins` directory beside BuffedItems and CoreLimiter.
2. Start or restart the server. The plugin creates `plugins/CoreCraftOnce/config.yml` and `data.yml`.
3. Use `/cco` in-game to open the core menu. Green entries are uncrafted; red entries have been crafted. Click a red entry to reset that core's limit. `/cco status` prints the counts in chat.
4. Edit `limits.default` or an individual core ID in `config.yml` to change crafting limits. A value of `0` means unlimited crafts.
5. Operators can also run `/cco reset <core-id>` to clear just that core's craft count, or `/cco give <player> <core-id> [amount]` to issue extra cores through BuffedItems without consuming the recipe limit. IDs are listed in `config.yml`.

The plugin keeps crafting active when its ledger write is queued to an asynchronous file writer. Do not remove `plugins/CoreCraftOnce/data.yml` if the server must retain the one-time craft limits.

## Build

Requires JDK 21. Run `./gradlew build`; the standalone plugin JAR is created under `build/libs/`.
