rootProject.name = "CoreCraftOnce"
