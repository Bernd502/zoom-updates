package net.corecraftonce;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Admin GUI showing every configured core and allowing one core's craft record to be reset. */
final class CoreCraftMenu implements InventoryHolder, Listener {
    private static final String TITLE = ChatColor.DARK_AQUA + "Core Craft Limits";

    private final CoreCraftOncePlugin plugin;
    private final Map<Integer, String> coreBySlot = new HashMap<>();
    private Inventory inventory;

    CoreCraftMenu(CoreCraftOncePlugin plugin) {
        this.plugin = plugin;
    }

    static void open(CoreCraftOncePlugin plugin, Player player) {
        CoreCraftMenu menu = new CoreCraftMenu(plugin);
        menu.refresh();
        player.openInventory(menu.inventory);
    }

    @Override public Inventory getInventory() {
        return inventory;
    }

    private void refresh() {
        List<String> ids = new ArrayList<>(plugin.cores().keySet());
        ids.sort(Comparator.naturalOrder());
        int size = Math.max(9, Math.min(54, ((ids.size() + 8) / 9) * 9));
        inventory = Bukkit.createInventory(this, size, TITLE);
        coreBySlot.clear();

        for (int slot = 0; slot < Math.min(ids.size(), size); slot++) {
            String id = ids.get(slot);
            coreBySlot.put(slot, id);
            int count = plugin.ledger().count(id);
            int limit = plugin.coreLimit(id);
            boolean crafted = count > 0;
            ItemStack icon = new ItemStack(crafted ? Material.RED_DYE : Material.LIME_DYE);
            ItemMeta meta = icon.getItemMeta();
            meta.setDisplayName((crafted ? ChatColor.RED : ChatColor.GREEN) + plugin.coreName(id));

            List<String> lore = new ArrayList<>();
            lore.add(ChatColor.GRAY + "ID: " + ChatColor.WHITE + id);
            lore.add(ChatColor.GRAY + "Crafted: " + (crafted ? ChatColor.RED + "Yes" : ChatColor.GREEN + "No"));
            lore.add(ChatColor.GRAY + "Server count: " + ChatColor.WHITE + count + "/" + (limit == 0 ? "∞" : limit));
            CraftLedger.Craft craft = plugin.ledger().get(id);
            if (craft != null) lore.add(ChatColor.GRAY + "Last crafted by: " + ChatColor.WHITE + craft.playerName());
            lore.add(" ");
            lore.add(crafted ? ChatColor.YELLOW + "Click to reset this core's limit" : ChatColor.DARK_GRAY + "Not crafted yet");
            meta.setLore(lore);
            icon.setItemMeta(meta);
            inventory.setItem(slot, icon);
        }
    }

    @EventHandler
    public void onMenuClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof CoreCraftMenu menu) || menu.plugin != plugin) return;
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player) || event.getRawSlot() < 0
                || event.getRawSlot() >= event.getView().getTopInventory().getSize()) return;

        String id = menu.coreBySlot.get(event.getRawSlot());
        if (id == null) return;
        if (plugin.ledger().count(id) == 0) {
            player.sendMessage(ChatColor.GREEN + plugin.coreName(id) + " has not been crafted yet.");
            return;
        }

        plugin.ledger().reset(id);
        player.sendMessage(plugin.message("admin-reset", Map.of("core", plugin.coreName(id))));
        menu.refresh();
    }

    @EventHandler
    public void onMenuDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof CoreCraftMenu menu && menu.plugin == plugin) {
            event.setCancelled(true);
        }
    }
}
