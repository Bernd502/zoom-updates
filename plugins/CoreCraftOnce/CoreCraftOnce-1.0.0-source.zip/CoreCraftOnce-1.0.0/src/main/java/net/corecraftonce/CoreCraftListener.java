package net.corecraftonce;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.CraftingInventory;
import org.bukkit.inventory.ItemStack;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

final class CoreCraftListener implements Listener {
    private final CoreCraftOncePlugin plugin;
    private final Set<String> pending = ConcurrentHashMap.newKeySet();

    CoreCraftListener(CoreCraftOncePlugin plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onCraftResultClick(InventoryClickEvent event) {
        if (event.getSlotType() != InventoryType.SlotType.RESULT || !(event.getClickedInventory() instanceof CraftingInventory inventory)) return;
        String coreId = plugin.coreId(inventory.getResult());
        if (coreId == null) return;
        String coreName = plugin.coreName(coreId);

        int limit = plugin.coreLimit(coreId);
        if (plugin.ledger().atLimit(coreId, limit) || pending.contains(coreId)) {
            event.setCancelled(true);
            event.getWhoClicked().sendMessage(plugin.message("used", Map.of("core", coreName)));
            return;
        }
        // BuffedItems implements shift crafting itself and may craft many outputs in one click.
        if (event.isShiftClick()) {
            event.setCancelled(true);
            event.getWhoClicked().sendMessage(plugin.message("shift-click", Map.of("core", coreName)));
            return;
        }
        if (!(event.getWhoClicked() instanceof Player player)) return;

        long before = countCore(player, coreId);
        pending.add(coreId);
        Bukkit.getScheduler().runTask(plugin, () -> {
            pending.remove(coreId);
            if (!player.isOnline() || countCore(player, coreId) <= before) return;
            if (plugin.ledger().claim(coreId, limit, player.getUniqueId(), player.getName()))
                player.sendMessage("§aYou crafted the unique " + coreName + ". No more can be crafted on this server.");
        });
    }

    private long countCore(Player player, String id) {
        long total = 0;
        for (ItemStack stack : player.getInventory().getContents()) if (id.equals(plugin.coreId(stack))) total += stack.getAmount();
        ItemStack cursor = player.getItemOnCursor();
        if (id.equals(plugin.coreId(cursor))) total += cursor.getAmount();
        return total;
    }
}
