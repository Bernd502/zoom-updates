package net.corecraftonce;

import org.bukkit.configuration.file.YamlConfiguration;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/** Server-wide one-time craft ledger. Mutations and YAML snapshots are made on the main thread. */
final class CraftLedger implements AutoCloseable {
    record Craft(int count, UUID playerId, String playerName, long craftedAt) {}

    private final Path file;
    private final ExecutorService writer = Executors.newSingleThreadExecutor(r -> {
        Thread thread = new Thread(r, "CoreCraftOnce-Storage");
        thread.setDaemon(true);
        return thread;
    });
    private final Map<String, Craft> crafts = new LinkedHashMap<>();

    CraftLedger(Path file) throws IOException {
        this.file = file;
        Files.createDirectories(file.getParent());
        if (Files.exists(file)) {
            YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file.toFile());
            var section = yaml.getConfigurationSection("crafted");
            if (section != null) for (String id : section.getKeys(false)) {
                String uuid = section.getString(id + ".uuid", "");
                try {
                    crafts.put(id.toLowerCase(java.util.Locale.ROOT), new Craft(Math.max(1, section.getInt(id + ".count", 1)), UUID.fromString(uuid),
                            section.getString(id + ".name", "Unknown"), section.getLong(id + ".at", 0)));
                } catch (IllegalArgumentException ignored) { /* Ignore a damaged row rather than blocking server startup. */ }
            }
        }
    }

    boolean atLimit(String id, int limit) { return limit > 0 && count(id) >= limit; }
    int count(String id) { Craft craft = crafts.get(normalize(id)); return craft == null ? 0 : craft.count(); }
    Craft get(String id) { return crafts.get(normalize(id)); }

    boolean claim(String id, int limit, UUID playerId, String playerName) {
        String key = normalize(id);
        Craft previous = crafts.get(key);
        if (limit > 0 && previous != null && previous.count() >= limit) return false;
        crafts.put(key, new Craft((previous == null ? 0 : previous.count()) + 1, playerId, playerName, System.currentTimeMillis()));
        saveAsync();
        return true;
    }

    void reset(String id) { crafts.remove(normalize(id)); saveAsync(); }

    private void saveAsync() {
        YamlConfiguration yaml = new YamlConfiguration();
        crafts.forEach((id, craft) -> {
            yaml.set("crafted." + id + ".count", craft.count());
            yaml.set("crafted." + id + ".uuid", craft.playerId().toString());
            yaml.set("crafted." + id + ".name", craft.playerName());
            yaml.set("crafted." + id + ".at", craft.craftedAt());
        });
        String snapshot = yaml.saveToString();
        writer.execute(() -> write(snapshot));
    }

    private void write(String snapshot) {
        Path temp = file.resolveSibling(file.getFileName() + ".tmp");
        try {
            Files.writeString(temp, snapshot, StandardCharsets.UTF_8);
            try { Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ignored) { Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException error) { System.err.println("[CoreCraftOnce] Could not save craft ledger: " + error.getMessage()); }
    }

    @Override public void close() {
        writer.shutdown();
        try {
            if (!writer.awaitTermination(3, TimeUnit.SECONDS)) writer.shutdownNow();
        } catch (InterruptedException error) {
            Thread.currentThread().interrupt();
            writer.shutdownNow();
        }
    }

    private static String normalize(String id) { return id.toLowerCase(java.util.Locale.ROOT); }
}
