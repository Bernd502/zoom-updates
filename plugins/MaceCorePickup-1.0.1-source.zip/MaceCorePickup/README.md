# MaceCorePickup

[Download the latest JAR](https://github.com/Bernd502/zoom-updates/raw/refs/heads/main/plugins/MaceCorePickup-1.0.1.jar)

A separate Paper 1.21.11 plugin for the CoreCraftOnce/BuffedItems setup. When protection is ON, a non-OP player carrying any of the ten configured BuffedItems cores cannot pick up a dropped vanilla mace. OPs bypass the restriction. A core counts only while it is in the player's inventory, armor/offhand slots, or cursor. CoreLimiter ownership and cores stored elsewhere do not count.

The plugin matches BuffedItems' `buffeditems:buffeditem_id` persistent-data value, using the same ten core IDs as CoreCraftOnce. Item names and lore do not count. It checks both the player's attempt to pick up an item and the final entity pickup event. Invalid core-ID configuration disables the plugin with a server-log error rather than silently ignoring entries. It only controls pickup of a mace item lying on the ground; crafting, opening containers, and admin commands are unaffected.

## Install

1. Put `MaceCorePickup-1.0.1.jar` in the Paper server's `plugins` folder alongside BuffedItems. Remove the older MaceCorePickup JAR if installed. CoreCraftOnce can stay installed; this is a separate plugin.
2. Restart the server. Edit `plugins/MaceCorePickup/config.yml` if your BuffedItems key or core IDs differ.
3. Test with a non-OP player carrying a core and a dropped mace. Remove the core from their inventory to allow pickup. Test with an OP to confirm the bypass.

An OP or the server console can run `/macecorepickup off`, `/macecorepickup on`, or `/macecorepickup toggle`. `/macecorepickup status` shows the current state. The short alias is `/mcpickup`. The state is saved to `plugins/MaceCorePickup/config.yml` and survives restarts; it starts ON. Non-OP players cannot use the command even if a permission plugin grants them its permission node.

## Build

Requires JDK 21. Run `./gradlew clean test build`. The JAR is created in `build/libs/`.
