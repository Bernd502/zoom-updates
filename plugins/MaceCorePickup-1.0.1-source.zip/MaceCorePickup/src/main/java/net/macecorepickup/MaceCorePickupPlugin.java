package net.macecorepickup;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.player.PlayerAttemptPickupItemEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.Material;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class MaceCorePickupPlugin extends JavaPlugin implements Listener {
    private final Map<UUID, Long> lastNotice = new HashMap<>();
    private NamespacedKey itemIdKey;
    private CorePickupRule rule;
    private boolean protectionEnabled;

    @Override public void onEnable() {
        saveDefaultConfig();
        itemIdKey = NamespacedKey.fromString(getConfig().getString("buffed-item-key", ""));
        try { rule = new CorePickupRule(getConfig().getStringList("core-ids")); }
        catch (IllegalArgumentException error) {
            getLogger().severe(error.getMessage());
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }
        if (itemIdKey == null) {
            getLogger().severe("Configure a valid buffed-item-key and at least one core ID; disabling.");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }
        protectionEnabled = getConfig().getBoolean("enabled", true);
        Bukkit.getPluginManager().registerEvents(this, this);
        if (!Bukkit.getPluginManager().isPluginEnabled("BuffedItems"))
            getLogger().warning("BuffedItems is not enabled. No carried items will match until it is available.");
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (mustBlock(player, event.getItem().getItemStack())) {
            event.setCancelled(true);
            notice(player);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onAttemptPickup(PlayerAttemptPickupItemEvent event) {
        Player player = event.getPlayer();
        if (mustBlock(player, event.getItem().getItemStack())) {
            event.setCancelled(true);
            notice(player);
        }
    }

    private boolean mustBlock(Player player, ItemStack groundItem) {
        return protectionEnabled && groundItem.getType() == Material.MACE && !player.isOp() && hasCore(player);
    }

    private void notice(Player player) {
        long now = System.currentTimeMillis();
        long cooldown = Math.max(0, getConfig().getLong("message-cooldown-ms", 3000));
        Long previous = lastNotice.get(player.getUniqueId());
        if (previous == null || now - previous >= cooldown) {
            lastNotice.put(player.getUniqueId(), now);
            String message = getConfig().getString("blocked-message", "&cYou cannot pick up a mace while carrying a core.");
            if (message != null && !message.isBlank()) player.sendMessage(ChatColor.translateAlternateColorCodes('&', message));
        }
    }

    @EventHandler public void onQuit(PlayerQuitEvent event) {
        lastNotice.remove(event.getPlayer().getUniqueId());
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        // Permission plugins cannot grant a non-operator the power to disable this rule.
        if (sender instanceof Player player && !player.isOp()) {
            sender.sendMessage(ChatColor.RED + "Only operators can change mace pickup protection.");
            return true;
        }
        if (!sender.hasPermission("macecorepickup.admin")) {
            sender.sendMessage(ChatColor.RED + "You do not have permission.");
            return true;
        }
        if (args.length > 1) return false;
        String action = args.length == 0 ? "status" : args[0].toLowerCase(Locale.ROOT);
        switch (action) {
            case "on" -> setProtectionEnabled(true);
            case "off" -> setProtectionEnabled(false);
            case "toggle" -> setProtectionEnabled(!protectionEnabled);
            case "status" -> { }
            default -> { return false; }
        }
        sender.sendMessage((protectionEnabled ? ChatColor.GREEN : ChatColor.YELLOW)
                + "Mace pickup protection is " + (protectionEnabled ? "ON" : "OFF") + ".");
        return true;
    }

    private void setProtectionEnabled(boolean value) {
        protectionEnabled = value;
        getConfig().set("enabled", value);
        saveConfig();
        lastNotice.clear();
        getLogger().info("Mace pickup protection " + (value ? "enabled" : "disabled") + " by an operator.");
    }

    @Override public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length != 1 || sender instanceof Player player && !player.isOp()
                || !sender.hasPermission("macecorepickup.admin")) return List.of();
        return List.of("on", "off", "toggle", "status").stream()
                .filter(option -> option.startsWith(args[0].toLowerCase(Locale.ROOT))).toList();
    }

    private boolean hasCore(Player player) {
        PlayerInventory inventory = player.getInventory();
        for (ItemStack item : inventory.getStorageContents()) if (isCore(item)) return true;
        for (ItemStack item : inventory.getArmorContents()) if (isCore(item)) return true;
        return isCore(inventory.getItemInOffHand()) || isCore(player.getItemOnCursor());
    }

    private boolean isCore(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) return false;
        String id = item.getItemMeta().getPersistentDataContainer().get(itemIdKey, PersistentDataType.STRING);
        return rule.matches(id);
    }
}
