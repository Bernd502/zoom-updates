package net.macelimiter;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class LimitPolicyTest {
    @Test void existingOverLimitArePreservedButNoNewOnesAreAdmitted() {
        assertFalse(LimitPolicy.allowNew(true, 1, 3));
        assertFalse(LimitPolicy.allowNew(true, 1, 1));
        assertTrue(LimitPolicy.allowNew(true, 4, 3));
        assertTrue(LimitPolicy.allowNew(false, 1, 3));
    }
}
