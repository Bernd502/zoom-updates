package net.macelimiter;

/** Pure admission rule: previously discovered maces are always grandfathered. */
public final class LimitPolicy {
    private LimitPolicy() { }
    public static boolean allowNew(boolean enabled, int limit, int tracked) {
        return !enabled || tracked < limit;
    }
}
