package net.macelimiter;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Chunk;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.block.BlockState;
import org.bukkit.block.Container;
import org.bukkit.block.Chest;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Item;
import org.bukkit.entity.ItemFrame;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ItemDespawnEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.block.CrafterCraftEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.InventoryCreativeEvent;
import org.bukkit.event.world.LootGenerateEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.BundleMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Tracks each observed physical mace with a persistent ID and prevents known new creation paths. */
public final class MaceLimiterPlugin extends JavaPlugin implements Listener {
    private record Record(String holder, String place, String scope, long seenAt) { }
    private final Map<String, Record> tracked = new HashMap<>();
    private final Set<String> primedScopes = new HashSet<>();
    private NamespacedKey idKey;
    private File ledgerFile;
    private boolean enabled;
    private int limit;

    @Override public void onEnable() {
        saveDefaultConfig();
        enabled = getConfig().getBoolean("enabled", true);
        limit = Math.max(0, getConfig().getInt("limit", 1));
        idKey = new NamespacedKey(this, "mace_id");
        ledgerFile = new File(getDataFolder(), "maces.yml");
        loadLedger();
        Bukkit.getPluginManager().registerEvents(this, this);
        // Existing loaded maces are grandfathered, even when the count already exceeds the cap.
        Bukkit.getScheduler().runTaskLater(this, this::scan, 2L);
        Bukkit.getScheduler().runTaskTimer(this, this::scan, 200L, 200L);
        Bukkit.getScheduler().runTaskTimer(this, this::saveLedger, 600L, 600L);
    }
    @Override public void onDisable() { saveLedger(); }

    private static boolean mace(ItemStack item) { return item != null && item.getType() == Material.MACE; }
    private String id(ItemStack item) {
        if (!mace(item)) return null;
        var meta = item.getItemMeta();
        return meta == null ? null : meta.getPersistentDataContainer().get(idKey, PersistentDataType.STRING);
    }
    private String assign(ItemStack item) {
        var meta = item.getItemMeta();
        if (meta == null) return null;
        String id = UUID.randomUUID().toString();
        meta.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, id);
        item.setItemMeta(meta);
        return id;
    }
    private boolean discover(ItemStack item, String holder, String place, String scope, Map<String, Record> found) {
        if (!mace(item)) return true;
        String id = id(item);
        boolean newId = id == null || found.containsKey(id);
        if (newId && enabled && primedScopes.contains(scope)
                && tracked.size() + found.keySet().stream().filter(key -> !tracked.containsKey(key)).count() >= limit)
            return false;
        if (newId) id = assign(item);
        if (id != null) found.put(id, new Record(holder, place, scope, System.currentTimeMillis()));
        return true;
    }
    private boolean inventory(Inventory inv, String holder, String place, String scope, Map<String, Record> found) {
        return inventory(inv, holder, place, scope, found, 0);
    }
    private boolean inventory(Inventory inv, String holder, String place, String scope, Map<String, Record> found, int depth) {
        boolean changed = false;
        for (int slot = 0; slot < inv.getSize(); slot++) {
            ItemStack item = inv.getItem(slot);
            if (item == null || item.getType().isAir()) continue;
            String before = id(item);
            String itemPlace = place + " · slot " + (slot + 1);
            if (mace(item) && !discover(item, holder, itemPlace, scope, found)) {
                inv.setItem(slot, null); changed = true; continue;
            }
            boolean nested = nested(item, holder, itemPlace, scope, found, depth + 1);
            if (nested || !java.util.Objects.equals(before, id(item))) { inv.setItem(slot, item); changed = true; }
        }
        return changed;
    }
    private boolean nested(ItemStack item, String holder, String place, String scope, Map<String, Record> found, int depth) {
        if (depth > 3 || !item.hasItemMeta()) return false;
        var meta = item.getItemMeta();
        if (meta instanceof BlockStateMeta blockMeta && blockMeta.hasBlockState()
                && blockMeta.getBlockState() instanceof Container container) {
            BlockState state = blockMeta.getBlockState();
            if (!(state instanceof Container contents)) return false;
            if (!inventory(contents.getInventory(), holder, place + " · stored", scope, found, depth)) return false;
            blockMeta.setBlockState(state); item.setItemMeta(blockMeta); return true;
        }
        if (meta instanceof BundleMeta bundle && bundle.hasItems()) {
            List<ItemStack> items = new ArrayList<>(bundle.getItems());
            boolean changed = false;
            for (int i = 0; i < items.size(); i++) {
                ItemStack child = items.get(i);
                String before = id(child);
                if (mace(child) && !discover(child, holder, place + " · bundle " + (i + 1), scope, found)) {
                    items.remove(i--); changed = true; continue;
                }
                changed |= nested(child, holder, place + " · bundle " + (i + 1), scope, found, depth + 1)
                        || !java.util.Objects.equals(before, id(child));
            }
            if (changed) { bundle.setItems(items); item.setItemMeta(bundle); }
            return changed;
        }
        return false;
    }
    private static String chunkScope(World world, int x, int z) {
        return "chunk:" + world.getUID() + ":" + x + ":" + z;
    }
    private void scan() {
        Map<String, Record> found = new HashMap<>();
        Set<String> scanned = new HashSet<>();
        for (Player player : Bukkit.getOnlinePlayers()) {
            String scope = "player:" + player.getUniqueId();
            scanned.add(scope);
            inventory(player.getInventory(), player.getName(), "Inventory", scope, found);
            inventory(player.getEnderChest(), player.getName(), "Ender Chest", scope, found);
            primedScopes.add(scope);
        }
        for (World world : Bukkit.getWorlds()) for (Chunk chunk : world.getLoadedChunks()) {
            String scope = chunkScope(world, chunk.getX(), chunk.getZ());
            scanned.add(scope);
            for (BlockState state : chunk.getTileEntities()) if (state instanceof Container container) {
                var pos = state.getLocation();
                Inventory contents = state instanceof Chest chest ? chest.getBlockInventory() : container.getInventory();
                if (inventory(contents, "—", world.getName() + " " + pos.getBlockX() + "," + pos.getBlockY() + "," + pos.getBlockZ(), scope, found))
                    container.update(true, false);
            }
            for (var entity : chunk.getEntities()) {
                ItemStack item = null;
                if (entity instanceof Item dropped) item = dropped.getItemStack();
                else if (entity instanceof ItemFrame frame) item = frame.getItem();
                else if (entity instanceof ItemDisplay display) item = display.getItemStack();
                else if (entity instanceof ArmorStand stand) item = stand.getEquipment().getItemInMainHand();
                var pos = entity.getLocation();
                String place = world.getName() + " " + pos.getBlockX() + "," + pos.getBlockY() + "," + pos.getBlockZ();
                if (mace(item)) {
                    String before = id(item);
                    if (!discover(item, "—", place, scope, found)) {
                        if (entity instanceof Item) entity.remove();
                        else if (entity instanceof ItemFrame frame) frame.setItem(new ItemStack(Material.AIR));
                        else if (entity instanceof ItemDisplay display) display.setItemStack(new ItemStack(Material.AIR));
                        else if (entity instanceof ArmorStand stand) stand.getEquipment().setItemInMainHand(new ItemStack(Material.AIR));
                    } else if (!java.util.Objects.equals(before, id(item))) {
                        if (entity instanceof Item dropped) dropped.setItemStack(item);
                        else if (entity instanceof ItemFrame frame) frame.setItem(item);
                        else if (entity instanceof ItemDisplay display) display.setItemStack(item);
                        else if (entity instanceof ArmorStand stand) stand.getEquipment().setItemInMainHand(item);
                    }
                }
                if (entity instanceof ArmorStand stand) {
                    ItemStack offhand = stand.getEquipment().getItemInOffHand();
                    if (mace(offhand)) {
                        String before = id(offhand);
                        if (!discover(offhand, "—", place + " · offhand", scope, found)) stand.getEquipment().setItemInOffHand(new ItemStack(Material.AIR));
                        else if (!java.util.Objects.equals(before, id(offhand))) stand.getEquipment().setItemInOffHand(offhand);
                    }
                }
            }
            primedScopes.add(scope);
        }
        // Retain last-known entries for offline players and unloaded chunks.
        long now = System.currentTimeMillis();
        tracked.entrySet().removeIf(entry -> !found.containsKey(entry.getKey())
                && (scanned.contains(entry.getValue().scope())
                || entry.getValue().scope().equals("pending") && now - entry.getValue().seenAt() > 30_000));
        tracked.putAll(found);
    }
    private boolean admitted() { return LimitPolicy.allowNew(enabled, limit, tracked.size()); }
    private void registerNew(ItemStack item, String place) {
        String id = id(item);
        if (id == null) id = assign(item);
        if (id != null) tracked.put(id, new Record("—", place, "pending", System.currentTimeMillis()));
    }
    private void blocked(Player player) {
        player.sendMessage(ChatColor.RED + "MaceLimiter: the server's " + limit + "-mace limit has been reached.");
    }
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPrepare(PrepareItemCraftEvent event) {
        if (enabled && mace(event.getInventory().getResult()) && !admitted()) event.getInventory().setResult(null);
    }
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCraft(CraftItemEvent event) {
        if (!mace(event.getCurrentItem()) || !enabled) return;
        if (!admitted() || event.isShiftClick()) {
            event.setCancelled(true);
            if (event.getWhoClicked() instanceof Player player) blocked(player);
            return;
        }
        ItemStack result = event.getCurrentItem();
        registerNew(result, "Crafted"); event.setCurrentItem(result);
    }
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCrafter(CrafterCraftEvent event) {
        ItemStack result = event.getResult();
        if (!mace(result) || !enabled) return;
        if (!admitted()) { event.setCancelled(true); return; }
        registerNew(result, "Crafter"); event.setResult(result);
    }
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCreative(InventoryCreativeEvent event) {
        ItemStack item = event.getCursor();
        if (!mace(item) || id(item) != null || !enabled) return;
        if (!admitted()) { event.setCancelled(true); if (event.getWhoClicked() instanceof Player player) blocked(player); return; }
        registerNew(item, "Creative"); event.setCursor(item);
    }
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onSpawn(ItemSpawnEvent event) {
        ItemStack item = event.getEntity().getItemStack();
        if (!mace(item) || id(item) != null || !enabled) return;
        if (!admitted()) { event.setCancelled(true); return; }
        registerNew(item, "Dropped item"); event.getEntity().setItemStack(item);
    }
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onLoot(LootGenerateEvent event) {
        if (!enabled) return;
        var loot = event.getLoot();
        for (int i = 0; i < loot.size(); i++) {
            ItemStack item = loot.get(i);
            if (!mace(item) || id(item) != null) continue;
            if (!admitted()) { loot.remove(i--); continue; }
            registerNew(item, "Generated loot"); loot.set(i, item);
        }
    }
    @EventHandler public void onDespawn(ItemDespawnEvent event) {
        String id = id(event.getEntity().getItemStack());
        if (id != null) tracked.remove(id);
    }
    @EventHandler public void onJoin(PlayerJoinEvent event) {
        Bukkit.getScheduler().runTaskLater(this, this::scan, 2L);
    }

    private void loadLedger() {
        if (!ledgerFile.isFile()) return;
        var yaml = YamlConfiguration.loadConfiguration(ledgerFile);
        for (String id : yaml.getKeys(false)) {
            if (!id.matches("[0-9a-fA-F-]{36}")) continue;
            String path = id + ".";
            tracked.put(id, new Record(yaml.getString(path + "holder", "—"), yaml.getString(path + "place", "Unknown"),
                    yaml.getString(path + "scope", "unknown"), yaml.getLong(path + "seen-at", 0)));
        }
    }
    private void saveLedger() {
        if (ledgerFile == null) return;
        var yaml = new YamlConfiguration();
        for (var entry : tracked.entrySet()) {
            String path = entry.getKey() + "."; Record record = entry.getValue();
            yaml.set(path + "holder", record.holder()); yaml.set(path + "place", record.place());
            yaml.set(path + "scope", record.scope()); yaml.set(path + "seen-at", record.seenAt());
        }
        try { yaml.save(ledgerFile); } catch (IOException error) { getLogger().warning("Could not save mace locations."); }
    }
    private void saveOptions() {
        getConfig().set("enabled", enabled); getConfig().set("limit", limit); saveConfig();
    }
    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof ConsoleCommandSender) && !(sender instanceof Player player && player.isOp())) {
            sender.sendMessage(ChatColor.RED + "Only operators can use /mace."); return true;
        }
        if (args.length == 0 || args[0].equalsIgnoreCase("status")) {
            scan();
            int page = 1;
            if (args.length > 1) try { page = Math.max(1, Integer.parseInt(args[1])); } catch (NumberFormatException ignored) { }
            status(sender, page); return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "on" -> { enabled = true; saveOptions(); sender.sendMessage(ChatColor.GREEN + "MaceLimiter enabled. Existing maces remain untouched."); }
            case "off" -> { enabled = false; saveOptions(); sender.sendMessage(ChatColor.YELLOW + "MaceLimiter disabled. Tracking remains active."); }
            case "limit" -> {
                if (args.length != 2) { sender.sendMessage(ChatColor.YELLOW + "Usage: /mace limit <number>"); return true; }
                try { limit = Integer.parseInt(args[1]); if (limit < 0 || limit > 10000) throw new NumberFormatException(); }
                catch (NumberFormatException error) { sender.sendMessage(ChatColor.RED + "Choose a whole number from 0 to 10000."); return true; }
                saveOptions(); sender.sendMessage(ChatColor.AQUA + "Mace limit set to " + limit + ". Existing maces remain untouched.");
            }
            default -> sender.sendMessage(ChatColor.YELLOW + "Usage: /mace [status [page]|on|off|limit <number>]");
        }
        return true;
    }
    private void status(CommandSender sender, int requestedPage) {
        var entries = new ArrayList<>(tracked.entrySet());
        entries.sort(Comparator.comparing((Map.Entry<String, Record> e) -> e.getValue().holder().equals("—"))
                .thenComparing(e -> e.getValue().holder()).thenComparing(Map.Entry::getKey));
        int pages = Math.max(1, (entries.size() + 7) / 8), page = Math.min(requestedPage, pages);
        String bar = "▰".repeat(Math.min(10, limit == 0 ? 10 : (int)Math.ceil(10.0 * tracked.size() / limit)))
                + "▱".repeat(Math.max(0, 10 - Math.min(10, limit == 0 ? 10 : (int)Math.ceil(10.0 * tracked.size() / limit))));
        sender.sendMessage(ChatColor.DARK_AQUA + "╔══════════ " + ChatColor.AQUA + "MACE LIMITER" + ChatColor.DARK_AQUA + " ══════════╗");
        sender.sendMessage(ChatColor.GRAY + "  Protection " + (enabled ? ChatColor.GREEN + "● ON" : ChatColor.RED + "● OFF")
                + ChatColor.DARK_GRAY + "  │  " + ChatColor.GRAY + "Tracked " + ChatColor.WHITE + tracked.size() + ChatColor.GRAY + " / " + ChatColor.WHITE + limit);
        sender.sendMessage((tracked.size() > limit ? ChatColor.RED : ChatColor.AQUA) + "  " + bar
                + (tracked.size() > limit ? ChatColor.RED + "  Existing maces grandfathered" : ""));
        if (entries.isEmpty()) sender.sendMessage(ChatColor.DARK_GRAY + "  No maces discovered yet.");
        for (int i = (page - 1) * 8; i < Math.min(entries.size(), page * 8); i++) {
            var entry = entries.get(i); Record record = entry.getValue();
            sender.sendMessage(ChatColor.DARK_AQUA + "  #" + (i + 1) + " " + ChatColor.WHITE
                    + (record.holder().equals("—") ? "Unheld" : record.holder()) + ChatColor.DARK_GRAY + "  •  "
                    + ChatColor.GRAY + record.place() + (lastKnown(record) ? ChatColor.DARK_GRAY + " (last known)" : ""));
        }
        sender.sendMessage(ChatColor.DARK_AQUA + "╚════════ " + ChatColor.GRAY + "Page " + page + "/" + pages
                + "  ·  /mace status <page>" + ChatColor.DARK_AQUA + " ════════╝");
    }
    private boolean lastKnown(Record record) {
        if (record.scope().startsWith("player:")) return Bukkit.getPlayerExact(record.holder()) == null;
        if (!record.scope().startsWith("chunk:")) return true;
        String[] parts = record.scope().split(":");
        if (parts.length != 4) return true;
        try {
            World world = Bukkit.getWorld(UUID.fromString(parts[1]));
            return world == null || !world.isChunkLoaded(Integer.parseInt(parts[2]), Integer.parseInt(parts[3]));
        } catch (IllegalArgumentException invalid) { return true; }
    }
    @Override public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!(sender instanceof ConsoleCommandSender) && !(sender instanceof Player player && player.isOp())) return List.of();
        if (args.length == 1) return List.of("status", "on", "off", "limit").stream()
                .filter(x -> x.startsWith(args[0].toLowerCase(Locale.ROOT))).toList();
        return List.of();
    }
}
