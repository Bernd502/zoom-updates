# MaceLimiter

Separate Paper 1.21.11 plugin for Minecraft servers. It tracks observed maces, defaults to one mace, and prevents new maces from manual crafting, crafters, generated loot, Creative placement, and item spawns once the limit is reached. After startup, it also rejects untracked new maces inserted directly into previously scanned player or container inventories. Existing maces discovered when a player or chunk is first scanned are kept even when they exceed the limit.

Put `MaceLimiter-1.0.0.jar` in the server's `plugins` folder and restart. Keep MaceCorePickup installed separately if you still want its core-carrying and storage rules. Settings are saved in `plugins/MaceLimiter/config.yml`; the ID and last known location ledger is `plugins/MaceLimiter/maces.yml`.

Only OPs and the server console can run:

- `/mace status [page]` — colored count, limit, protection state, holders and locations. Offline players and unloaded chunks show their last known locations.
- `/mace on` and `/mace off` — change enforcement without deleting tracked maces. Tracking continues when enforcement is off.
- `/mace limit <number>` — set the maximum from 0 through 10000. Existing maces remain untouched.

The plugin scans online inventories (including Ender Chests), loaded storage blocks, dropped items, item frames, item displays, armor stands, and nested shulker/bundle contents. It retains last known entries for offline players and unloaded chunks. An unseen mace in an offline player's inventory or unloaded chunk cannot appear in `/mace status` until that player joins or the chunk loads. The plugin does not inspect server files or force-load chunks.

Build and test with Java 21: `./gradlew clean test build`. The installable JAR is in `build/libs/`.
