package net.corecraftonce;

import org.bukkit.ChatColor;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.persistence.PersistentDataType;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public final class CoreCraftOncePlugin extends JavaPlugin {
    private CraftLedger ledger;
    private NamespacedKey itemIdKey;
    private Map<String, String> cores = Map.of();

    @Override public void onEnable() {
        saveDefaultConfig();
        loadCoreConfig();
        String configuredKey = getConfig().getString("buffed-item-key", "buffeditems:buffeditem_id");
        itemIdKey = NamespacedKey.fromString(configuredKey);
        if (itemIdKey == null) {
            getLogger().severe("Invalid buffed-item-key in config.yml; disabling.");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }
        try { ledger = new CraftLedger(getDataFolder().toPath().resolve("data.yml")); }
        catch (IOException error) {
            getLogger().severe("Could not open persistent craft ledger: " + error.getMessage());
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }
        Bukkit.getPluginManager().registerEvents(new CoreCraftListener(this), this);
        Bukkit.getPluginManager().registerEvents(new CoreCraftMenu(this, false), this);
        getLogger().info("Loaded " + cores.size() + " core craft limits; " + cores.keySet().stream().filter(id -> ledger.count(id) > 0).count() + " already used.");
        if (!Bukkit.getPluginManager().isPluginEnabled("BuffedItems"))
            getLogger().warning("BuffedItems is not installed; the configured item IDs will not match craft results until it is enabled.");
    }

    @Override public void onDisable() { if (ledger != null) ledger.close(); }

    private void loadCoreConfig() {
        var section = getConfig().getConfigurationSection("cores");
        Map<String, String> result = new LinkedHashMap<>();
        if (section != null) for (String id : section.getKeys(false)) {
            String label = section.getString(id, id);
            if (id.matches("[a-z0-9_]+") && label != null && !label.isBlank()) result.put(id.toLowerCase(Locale.ROOT), label);
            else getLogger().warning("Ignoring invalid core entry: " + id);
        }
        cores = Map.copyOf(result);
    }

    String coreId(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return null;
        String id = stack.getItemMeta().getPersistentDataContainer().get(itemIdKey, PersistentDataType.STRING);
        return id == null ? null : cores.containsKey(id.toLowerCase(Locale.ROOT)) ? id.toLowerCase(Locale.ROOT) : null;
    }
    CraftLedger ledger() { return ledger; }
    String coreName(String id) { return cores.getOrDefault(id.toLowerCase(Locale.ROOT), id); }
    Map<String, String> cores() { return cores; }
    int coreLimit(String id) { return Math.max(0, getConfig().getInt("limits." + id.toLowerCase(Locale.ROOT), getConfig().getInt("limits.default", 1))); }
    String message(String key, Map<String, String> replacements) {
        String value = getConfig().getString("messages." + key, "");
        for (var entry : replacements.entrySet()) value = value.replace("{" + entry.getKey() + "}", entry.getValue());
        return ChatColor.translateAlternateColorCodes('&', value);
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            if (sender instanceof Player player) CoreCraftMenu.open(this, player);
            else showStatus(sender);
            return true;
        }
        if (args.length == 1 && args[0].equalsIgnoreCase("status")) {
            showStatus(sender);
            return true;
        }
        if (!sender.hasPermission("corecraftonce.admin")) {
            sender.sendMessage(ChatColor.RED + "Only admins can reset or give cores.");
            return true;
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("reset")) {
            String id = args[1].toLowerCase(Locale.ROOT);
            if (!cores.containsKey(id)) { sender.sendMessage(message("unknown-core", Map.of())); return true; }
            ledger.reset(id);
            sender.sendMessage(message("admin-reset", Map.of("core", coreName(id))));
            return true;
        }
        if (args.length >= 3 && args.length <= 4 && args[0].equalsIgnoreCase("give")) {
            if (!Bukkit.getPluginManager().isPluginEnabled("BuffedItems")) {
                sender.sendMessage(message("give-failed", Map.of())); return true;
            }
            Player target = Bukkit.getPlayerExact(args[1]);
            String id = args[2].toLowerCase(Locale.ROOT);
            int amount = 1;
            try { if (args.length == 4) amount = Integer.parseInt(args[3]); }
            catch (NumberFormatException error) { sender.sendMessage(ChatColor.RED + "Amount must be a number from 1 to 64."); return true; }
            if (!cores.containsKey(id)) { sender.sendMessage(message("unknown-core", Map.of())); return true; }
            if (target == null || amount < 1 || amount > 64) { sender.sendMessage(message("give-failed", Map.of())); return true; }
            boolean dispatched = Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "buffeditems give " + target.getName() + " " + id + " " + amount);
            if (dispatched) sender.sendMessage(message("give-success", Map.of("amount", Integer.toString(amount), "core", coreName(id), "player", target.getName())));
            else sender.sendMessage(message("give-failed", Map.of()));
            return true;
        }
        sender.sendMessage(ChatColor.YELLOW + "Usage: /cco [status|reset <core-id>|give <player> <core-id> [amount]]");
        return true;
    }

    private void showStatus(CommandSender sender) {
        sender.sendMessage(message("status-header", Map.of()));
        cores.forEach((id, name) -> {
            CraftLedger.Craft craft = ledger.get(id);
            int limit = coreLimit(id), count = ledger.count(id);
            sender.sendMessage(message("status-count", Map.of("core", name, "count", Integer.toString(count),
                    "limit", limit == 0 ? "∞" : Integer.toString(limit), "player", craft == null ? "-" : craft.playerName())));
        });
    }

    @Override public java.util.List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return prefix(sender.hasPermission("corecraftonce.admin")
                ? java.util.List.of("status", "reset", "give") : java.util.List.of("status"), args[0]);
        if (!sender.hasPermission("corecraftonce.admin")) return java.util.List.of();
        if (args.length == 2 && args[0].equalsIgnoreCase("reset"))
            return prefix(new ArrayList<>(cores.keySet()), args[1]);
        if (args.length == 2 && args[0].equalsIgnoreCase("give"))
            return prefix(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), args[1]);
        if (args.length == 3 && args[0].equalsIgnoreCase("give"))
            return prefix(new ArrayList<>(cores.keySet()), args[2]);
        return java.util.List.of();
    }

    private java.util.List<String> prefix(java.util.List<String> candidates, String input) {
        return candidates.stream().filter(value -> value.regionMatches(true, 0, input, 0, input.length()))
                .sorted(Comparator.naturalOrder()).toList();
    }
}
