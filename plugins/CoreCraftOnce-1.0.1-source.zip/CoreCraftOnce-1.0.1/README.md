# CoreCraftOnce

[Download CoreCraftOnce 1.0.1](https://github.com/Bernd502/zoom-updates/raw/refs/heads/main/plugins/CoreCraftOnce-1.0.1.jar)

Paper 1.21.11 companion plugin for the supplied BuffedItems and CoreLimiter setup. It allows the first successful craft of each configured BuffedItems core on the server, then blocks future crafts of that core. Its ledger survives restarts.

The plugin identifies custom items using BuffedItems' `buffeditems:buffeditem_id` persistent-data key and only limits the ten core IDs from the supplied `items.yml`; unrelated items made from `HEAVY_CORE` are unaffected. Shift-click crafting of a unique core is denied because BuffedItems' shift-click handler can produce several outputs in one action. A normal click can craft the one allowed core.

Everyone can run `/cco status` to see each core's craft count and limit. Players can also run `/cco` to open a read-only status menu. Only players with `corecraftonce.admin` (operators by default) can click a crafted core to reset it, run `/cco reset <core-id>`, or run `/cco give <player> <core-id> [amount]`. The console can run `/cco` or `/cco status` for text status. The command alias is `/corecraftonce`.

## Install

1. Copy `CoreCraftOnce-1.0.1.jar` into the Paper server's `plugins` directory beside BuffedItems and CoreLimiter. Remove any older CoreCraftOnce JAR first.
2. Start or restart the server. The plugin creates `plugins/CoreCraftOnce/config.yml` and `data.yml`.
3. As a non-OP, use `/cco status` or `/cco` to view core status. Try clicking a crafted core; it should not reset. As an OP, test the reset action.
4. Edit `limits.default` or an individual core ID in `config.yml` to change crafting limits. A value of `0` means unlimited crafts.

The plugin keeps crafting active when its ledger write is queued to an asynchronous file writer. Do not remove `plugins/CoreCraftOnce/data.yml` if the server must retain the one-time craft limits.

## Build

Requires JDK 21. Run `./gradlew build`; the standalone plugin JAR is created under `build/libs/`.
