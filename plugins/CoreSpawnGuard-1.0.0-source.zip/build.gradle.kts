plugins { java }

group = "net.corespawnguard"
version = "1.0.0"

java { toolchain.languageVersion.set(JavaLanguageVersion.of(21)) }
repositories { mavenCentral(); maven("https://repo.papermc.io/repository/maven-public/") }
dependencies {
    compileOnly("io.papermc.paper:paper-api:1.21.11-R0.1-SNAPSHOT")
    compileOnly(files("libs/BuffedItems-1.9.0.jar"))
    testImplementation("io.papermc.paper:paper-api:1.21.11-R0.1-SNAPSHOT") { isTransitive = false }
    testImplementation("net.kyori:adventure-api:4.26.1") { isTransitive = false }
    testImplementation("net.kyori:adventure-key:4.26.1") { isTransitive = false }
    testImplementation("net.kyori:examination-api:1.3.0") { isTransitive = false }
    testImplementation(files("libs/BuffedItems-1.9.0.jar"))
    testImplementation("org.junit.jupiter:junit-jupiter:5.13.4")
    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
}
tasks.test { useJUnitPlatform() }
tasks.processResources {
    filteringCharset = "UTF-8"
    filesMatching("plugin.yml") { expand("version" to project.version) }
}
