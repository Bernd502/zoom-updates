# CoreSpawnGuard

Separate Paper **1.21.11** plugin for **BuffedItems 1.9.0**. It disables the configured BuffedItems cores' active abilities and passive potion/attribute effects inside a square around spawn. Cores stay in the player's inventory. This plugin uses BuffedItems' own active and passive permission checks, so it does not remove items or strip unrelated effects.

The default square extends 32 blocks in X and Z from `world`'s spawn point, at every height. Edit `plugins/CoreSpawnGuard/config.yml` to change `radius`, `worlds`, and the core IDs, then restart. Use `worlds: ["*"]` to apply the radius around every world's spawn. The plugin requires the exact supported BuffedItems version and disables itself if the integration layout differs.

OPs and the server console can use `/corespawn status`, `/corespawn on`, `/corespawn off`, and `/corespawn radius <blocks>`. The enable state and radius save immediately. Crossing the boundary updates permission checks; BuffedItems removes its passive effects on its next effect pass, normally within one second. A timed active effect cast *before* entering spawn may continue until its normal expiry, because the plugin does not remove a potion effect that might have another source.

Install `CoreSpawnGuard-1.0.0.jar` alongside BuffedItems in the Paper server's `plugins` folder. It can also run alongside CoreCraftOnce and MaceCorePickup. No client mod is required.

Build with Java 21: `./gradlew clean test build`. The installable JAR is in `build/libs/`. The included BuffedItems 1.9.0 JAR is a compile-only reference and is not bundled into CoreSpawnGuard. BuffedItems is Copyright (c) 2025 StreetMelodeez (AltKat), MIT License (see `libs/BuffedItems-LICENSE.txt`).
