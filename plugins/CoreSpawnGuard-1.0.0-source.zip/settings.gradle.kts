rootProject.name = "CoreSpawnGuard"
