package net.corespawnguard;

/** Inclusive square region around a world's spawn, independent of height. */
public final class SpawnZone {
    private SpawnZone() { }
    public static boolean contains(int x, int z, int spawnX, int spawnZ, int radius) {
        if (radius < 0) throw new IllegalArgumentException("radius must be nonnegative");
        return Math.abs((long)x - spawnX) <= radius && Math.abs((long)z - spawnZ) <= radius;
    }
}
