package net.corespawnguard;

import io.github.altkat.BuffedItems.BuffedItems;
import io.github.altkat.BuffedItems.utility.item.BuffedItem;
import io.github.altkat.BuffedItems.utility.item.data.ActiveAbility;
import io.github.altkat.BuffedItems.utility.item.data.PassiveEffects;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.World;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionAttachment;
import org.bukkit.permissions.PermissionDefault;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Bridges BuffedItems 1.9.0 active/passive permissions to a configurable spawn area. */
public final class CoreSpawnGuardPlugin extends JavaPlugin implements Listener {
    private record Patch(BuffedItem original, BuffedItem replacement, String activeOriginal,
                         String passiveOriginal, String activeNode, String passiveNode) { }
    private final Map<String, Patch> patches = new HashMap<>();
    private final Map<UUID, PermissionAttachment> attachments = new HashMap<>();
    private final Map<UUID, Map<String, Boolean>> applied = new HashMap<>();
    private final Set<String> registeredNodes = new HashSet<>();
    private BuffedItems buffed;
    private Field itemsField;
    private boolean enabled;
    private int radius;
    private Set<String> worlds;

    @Override public void onEnable() {
        saveDefaultConfig();
        if (!(Bukkit.getPluginManager().getPlugin("BuffedItems") instanceof BuffedItems dependency)
                || !dependency.isEnabled() || !dependency.getDescription().getVersion().equals("1.9.0")) {
            getLogger().severe("CoreSpawnGuard requires BuffedItems 1.9.0; no core settings were changed.");
            Bukkit.getPluginManager().disablePlugin(this); return;
        }
        buffed = dependency;
        try {
            itemsField = dependency.getItemManager().getClass().getDeclaredField("buffedItems");
            itemsField.setAccessible(true);
            items();
        } catch (ReflectiveOperationException | RuntimeException incompatible) {
            getLogger().severe("BuffedItems item layout is incompatible; disabling CoreSpawnGuard without changes.");
            Bukkit.getPluginManager().disablePlugin(this); return;
        }
        loadOptions();
        try { patchItems(); }
        catch (ReflectiveOperationException | RuntimeException incompatible) {
            getLogger().severe("Could not install BuffedItems permission bridge; disabling CoreSpawnGuard.");
            Bukkit.getPluginManager().disablePlugin(this); return;
        }
        Bukkit.getPluginManager().registerEvents(this, this);
        for (Player player : Bukkit.getOnlinePlayers()) refresh(player);
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            try {
                patchItems();
                for (Player player : Bukkit.getOnlinePlayers()) refresh(player);
            }
            catch (ReflectiveOperationException | RuntimeException incompatible) {
                getLogger().severe("BuffedItems changed unexpectedly; CoreSpawnGuard has been disabled.");
                Bukkit.getPluginManager().disablePlugin(this);
            }
        }, 2L, 2L);
    }
    @Override public void onDisable() {
        if (itemsField != null && buffed != null && buffed.isEnabled()) {
            try {
                Map<String, BuffedItem> items = items();
                for (var entry : patches.entrySet())
                    if (items.get(entry.getKey()) == entry.getValue().replacement())
                        items.put(entry.getKey(), entry.getValue().original());
                for (Player player : Bukkit.getOnlinePlayers()) buffed.getEffectApplicatorTask().markPlayerForUpdate(player.getUniqueId());
            } catch (ReflectiveOperationException | RuntimeException ignored) { }
        }
        for (var attachment : attachments.values()) {
            try { attachment.remove(); } catch (IllegalArgumentException ignored) { }
        }
        attachments.clear(); applied.clear(); patches.clear();
        for (String node : registeredNodes) Bukkit.getPluginManager().removePermission(node);
        registeredNodes.clear();
    }
    private void loadOptions() {
        enabled = getConfig().getBoolean("enabled", true);
        radius = Math.max(0, Math.min(4096, getConfig().getInt("radius", 32)));
        worlds = getConfig().getStringList("worlds").stream().map(s -> s.toLowerCase(Locale.ROOT)).collect(java.util.stream.Collectors.toSet());
    }
    @SuppressWarnings("unchecked")
    private Map<String, BuffedItem> items() throws ReflectiveOperationException {
        return (Map<String, BuffedItem>) itemsField.get(buffed.getItemManager());
    }
    private void registerNode(String node) {
        if (Bukkit.getPluginManager().getPermission(node) == null) {
            Bukkit.getPluginManager().addPermission(new Permission(node, PermissionDefault.FALSE));
            registeredNodes.add(node);
        }
    }
    private static String originalPermission(String special, String base) {
        return special != null && !special.equalsIgnoreCase("NONE") ? special : base;
    }
    private static String originalPassivePermission(String special, String base) {
        // EffectApplicatorTask treats an explicit NONE as unrestricted, even if a base permission exists.
        return special == null ? base : special;
    }
    private static boolean hasOriginalPermission(Player player, String node) {
        return node == null || node.equalsIgnoreCase("NONE") || player.hasPermission(node);
    }
    static BuffedItem replacement(BuffedItem source, String activeNode, String passiveNode) {
        var oldActive = source.getActiveAbility();
        var oldPassive = source.getPassiveEffects();
        var active = new ActiveAbility(oldActive.isEnabled(), oldActive.getCooldown(), oldActive.getDuration(),
                activeNode, oldActive.getCommands(), oldActive.getEffects(), oldActive.getVisuals(),
                oldActive.getSounds(), oldActive.getCosts());
        var passive = new PassiveEffects(oldPassive.getEffects(), oldPassive.getAttributeMode(), passiveNode);
        var copy = new BuffedItem(source.getId(), source.getMaterial(), source.getPermission(),
                source.getUpdateHash(), source.hasPlaceholders(), source.getItemDisplay(), passive,
                source.getPassiveVisuals(), active, source.getUsageDetails(), source.getFlags(),
                source.getEnchantments(), source.getBaseItem());
        copy.setCachedItem(source.getCachedItem());
        for (String error : source.getErrorMessages()) copy.addErrorMessage(error);
        return copy;
    }
    /** Reapplies after /bi reload replaces its item objects. */
    private boolean patchItems() throws ReflectiveOperationException {
        Map<String, BuffedItem> items = items();
        boolean changed = false;
        for (String id : getConfig().getStringList("core-ids")) {
            if (!id.matches("[a-z0-9_]+")) continue;
            BuffedItem current = items.get(id);
            if (current == null || patches.containsKey(id) && patches.get(id).replacement() == current) continue;
            String activeNode = "corespawnguard.active." + id;
            String passiveNode = "corespawnguard.passive." + id;
            registerNode(activeNode); registerNode(passiveNode);
            BuffedItem wrapped = replacement(current, activeNode, passiveNode);
            patches.put(id, new Patch(current, wrapped,
                    originalPermission(current.getActiveAbility().getActivePermission(), current.getPermission()),
                    originalPassivePermission(current.getPassiveEffects().getPassivePermission(), current.getPermission()),
                    activeNode, passiveNode));
            items.put(id, wrapped); changed = true;
        }
        if (changed) for (Player player : Bukkit.getOnlinePlayers())
            buffed.getEffectApplicatorTask().markPlayerForUpdate(player.getUniqueId());
        return changed;
    }
    private boolean inside(Location here) {
        if (!enabled) return false;
        World world = here.getWorld();
        if (world == null) return false;
        if (!worlds.contains("*") && !worlds.contains(world.getName().toLowerCase(Locale.ROOT))) return false;
        var spawn = world.getSpawnLocation();
        return SpawnZone.contains(here.getBlockX(), here.getBlockZ(), spawn.getBlockX(), spawn.getBlockZ(), radius);
    }
    private void refresh(Player player) { refresh(player, player.getLocation()); }
    private void refresh(Player player, Location location) {
        PermissionAttachment attachment = attachments.computeIfAbsent(player.getUniqueId(), ignored -> player.addAttachment(this));
        Map<String, Boolean> values = applied.computeIfAbsent(player.getUniqueId(), ignored -> new HashMap<>());
        boolean blocked = inside(location), changed = false;
        for (Patch patch : patches.values()) {
            boolean active = !blocked && hasOriginalPermission(player, patch.activeOriginal());
            boolean passive = !blocked && hasOriginalPermission(player, patch.passiveOriginal());
            if (!java.util.Objects.equals(values.put(patch.activeNode(), active), active)) {
                attachment.setPermission(patch.activeNode(), active); changed = true;
            }
            if (!java.util.Objects.equals(values.put(patch.passiveNode(), passive), passive)) {
                attachment.setPermission(patch.passiveNode(), passive); changed = true;
            }
        }
        if (changed) buffed.getEffectApplicatorTask().markPlayerForUpdate(player.getUniqueId());
    }
    @EventHandler(priority = EventPriority.LOWEST) public void onInteract(PlayerInteractEvent event) { refresh(event.getPlayer()); }
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (event.getTo() != null && (event.getFrom().getBlockX() != event.getTo().getBlockX()
                || event.getFrom().getBlockZ() != event.getTo().getBlockZ())) refresh(event.getPlayer(), event.getTo());
    }
    @EventHandler public void onWorld(PlayerChangedWorldEvent event) { refresh(event.getPlayer()); }
    @EventHandler public void onJoin(PlayerJoinEvent event) { refresh(event.getPlayer()); }
    @EventHandler public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        var attachment = attachments.remove(id); if (attachment != null) attachment.remove();
        applied.remove(id);
    }
    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof ConsoleCommandSender) && !(sender instanceof Player player && player.isOp())) {
            sender.sendMessage(ChatColor.RED + "Only operators can use this command."); return true;
        }
        if (args.length == 0 || args[0].equalsIgnoreCase("status")) {
            sender.sendMessage(ChatColor.AQUA + "CoreSpawnGuard " + (enabled ? ChatColor.GREEN + "ON" : ChatColor.RED + "OFF")
                    + ChatColor.GRAY + " | radius " + radius + " | worlds " + worlds + " | cores " + patches.size()); return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "on" -> enabled = true;
            case "off" -> enabled = false;
            case "radius" -> {
                if (args.length != 2) { sender.sendMessage(ChatColor.YELLOW + "Usage: /corespawn radius <blocks>"); return true; }
                try { radius = Integer.parseInt(args[1]); if (radius < 0 || radius > 4096) throw new NumberFormatException(); }
                catch (NumberFormatException invalid) { sender.sendMessage(ChatColor.RED + "Choose 0 to 4096 blocks."); return true; }
            }
            default -> { sender.sendMessage(ChatColor.YELLOW + "Usage: /corespawn [status|on|off|radius <blocks>]"); return true; }
        }
        getConfig().set("enabled", enabled); getConfig().set("radius", radius); saveConfig();
        for (Player player : Bukkit.getOnlinePlayers()) refresh(player);
        sender.sendMessage(ChatColor.GREEN + "CoreSpawnGuard updated: " + (enabled ? "ON" : "OFF") + ", radius " + radius + ".");
        return true;
    }
    @Override public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!(sender instanceof ConsoleCommandSender) && !(sender instanceof Player player && player.isOp())) return List.of();
        return args.length == 1 ? List.of("status", "on", "off", "radius").stream()
                .filter(option -> option.startsWith(args[0].toLowerCase(Locale.ROOT))).toList() : List.of();
    }
}
