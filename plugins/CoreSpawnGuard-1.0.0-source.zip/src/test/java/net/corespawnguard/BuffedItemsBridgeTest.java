package net.corespawnguard;

import io.github.altkat.BuffedItems.manager.item.ItemManager;
import io.github.altkat.BuffedItems.utility.item.BuffedItem;
import io.github.altkat.BuffedItems.utility.item.data.ActiveAbility;
import io.github.altkat.BuffedItems.utility.item.data.PassiveEffects;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class BuffedItemsBridgeTest {
    @Test void versionedItemMapAndPermissionFieldsExist() throws Exception {
        assertEquals(Map.class, ItemManager.class.getDeclaredField("buffedItems").getType());
        assertEquals(String.class, PassiveEffects.class.getDeclaredField("passivePermission").getType());
        assertEquals(String.class, ActiveAbility.class.getDeclaredField("activePermission").getType());
    }
    @Test void versionedCorePropertiesUsedByBridgeExist() throws Exception {
        assertNotNull(BuffedItem.class.getMethod("getUpdateHash"));
        assertNotNull(BuffedItem.class.getMethod("getBaseItem"));
        assertNotNull(BuffedItem.class.getMethod("getActiveAbility"));
        assertNotNull(BuffedItem.class.getMethod("getPassiveEffects"));
        assertNotNull(ActiveAbility.class.getMethod("getActivePermission"));
        assertNotNull(PassiveEffects.class.getMethod("getPassivePermission"));
    }
}
