package net.corespawnguard;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SpawnZoneTest {
    @Test void includesBothEdgesAndEveryHeight() {
        assertTrue(SpawnZone.contains(32, -32, 0, 0, 32));
        assertTrue(SpawnZone.contains(-32, 32, 0, 0, 32));
        assertFalse(SpawnZone.contains(33, 0, 0, 0, 32));
        assertFalse(SpawnZone.contains(0, -33, 0, 0, 32));
    }
}
