plugins { java }
group = "net.sfmode"
version = "0.2.0"
java { toolchain.languageVersion.set(JavaLanguageVersion.of(21)) }
repositories { mavenCentral(); maven("https://repo.papermc.io/repository/maven-public/") }
dependencies {
    compileOnly("io.papermc.paper:paper-api:1.21.11-R0.1-SNAPSHOT")
    compileOnly("net.luckperms:api:5.4")
    implementation("org.xerial:sqlite-jdbc:3.50.3.0")
    testImplementation("io.papermc.paper:paper-api:1.21.11-R0.1-SNAPSHOT") { isTransitive = false }
    testImplementation("org.junit.jupiter:junit-jupiter:5.13.4")
    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
}
tasks.test { useJUnitPlatform() }
tasks.processResources { filesMatching("plugin.yml") { expand("version" to project.version) } }
tasks.jar { from(configurations.runtimeClasspath.get().filter { it.name.startsWith("sqlite-jdbc") }.map { zipTree(it) }); duplicatesStrategy = DuplicatesStrategy.EXCLUDE }
