# SFMode (work in progress)

Paper 1.21.11 + LuckPerms 5.4 administrator-session plugin. This is a development checkpoint, **not a production-ready release**. Do not install on a live SMP yet.

Implemented so far: console/owner UUID allowlist, durable SQLite inventory snapshots and session states, temporary Creative/OP/LuckPerms `dev` group, recovery gating, event-based audit and item origin tags, basic read-only inventory GUI, limited online-player rollback preview/confirmation, alerts, and optional Discord webhook queue. A SQLite driver is bundled in the jar.

Still requires a real Paper/LuckPerms integration test and security review. In particular, complete provenance across arbitrary plugins, all crafting/container paths, exact stack quantities, offline inventory rollback, unloaded chunks, persistent spectator restoration, and full GUI filters are not implemented. Item origins are batch IDs, not unique physical-item IDs. Never assume an untagged item is legitimate.

Build with `JAVA_HOME` pointing to a Java 21 JDK and `./gradlew test build`. The jar is under `build/libs/`. Keep the `plugins/SFMode` data folder and its SQLite database backed up. To authorize someone, use the server console: `/sfmode allow <player-or-UUID>`. That player also needs `sfmode.use` from LuckPerms. `/sfmode` toggles, `/sfmode status` shows state. The plugin requires LuckPerms and will not enable without it.
