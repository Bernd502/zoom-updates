# SFMode implementation status

This page records what the current source actually does. It is not a claim of production readiness.

## Implemented

- Paper 1.21.11 / Java 21 Gradle plugin; requires LuckPerms.
- Console allowlist commands using UUIDs; optional configured owner UUID plus independent management permission.
- Inventory snapshot codec based on Paper's item byte serialization, bounded size, SHA-256 verification, SQLite WAL and full synchronous commits.
- Explicit session states, temporary OP and direct LuckPerms group assignment, restore of gamemode, flight flags, cursor and inventory.
- Recovery preview and owner-confirmed online-player recovery. Ambiguous activation refuses to overwrite the current inventory until confirmed.
- Permission-gated command, world, item, transfer, crafting, smelting, anvil, smithing and block observations. Item metadata is invisible PDC and origin IDs identify batches.
- Cooperating plugin hook: `SFModeApi` service `tagCreatedItem`.
- Read-only inventory views for origins, audit, sessions, alerts, rollback records and pending recovery. Session monitor sends an action bar update.
- Owner-confirmed rollback preview for currently online player inventory items whose origin resolves to the requested session.
- Optional bounded Discord webhook queue.

## Known gaps and API limits

- A Paper 1.21.11 server with LuckPerms 5.5.71 loaded SFMode 0.2.0, enabled cleanly, answered `/sfmode status`, accepted a console UUID allowlist entry, listed it, and shut down cleanly. This smoke test did not create a real player session or exercise inventory/permission restoration; those still require a staging player test.
- Audit events now use a bounded 8,192-entry SQLite writer queue; session transitions and audit queries still use synchronous SQLite access on the server thread. Queue overflow is reported, and writer failures suspend active sessions on the next health check. Query latency and SQLite contention still need profiling on a staging server.
- Creative inventory events are evidence of a Creative packet, not proof of physical creation. They are marked `CREATION_INFERRED`.
- A stack-level PDC origin cannot track exact individual items after split, merge, clone, recipe repetition, hopper transfers or arbitrary plugin changes. Counts and transfers are observations, not a perfect ledger.
- Crafting previews may be recalculated repeatedly. The code records a transform on craft click but cannot accurately infer shift-click quantities. Some transformations and recipe types are uncovered.
- Transfer log coverage includes clicks, drops, pickups and hopper moves. It does not inspect all block inventories or offline players. Rollback only removes tagged items currently in online player inventories; it does not remove containers, dropped items, blocks or offline inventories.
- Block provenance records a coordinate and material. External edits can stale that record; breaking does not transfer origin metadata to drops.
- Monitoring is a current-state action bar, not a complete live session timeline. Spectator mode is not implemented.
- GUI search, date/material filters, full item detail pages, rollback GUI confirmation and alert review history are incomplete. Commands provide the safer owner confirmation path for recovery and rollback.
- Discord delivery is best effort. Discord is not an audit store. The webhook is read from config and must never be shared.
- A server owner with filesystem or console access can alter the plugin/database. Real OP cannot be made tamper-proof by a Bukkit plugin.

## Release gate

Before any live deployment: verify activation/deactivation/recovery on a staging server with LuckPerms; inject process stops at each persisted transition; verify inventory snapshots and permission restoration after restart; test all transformations and transfer types; test database-full, disk-error and webhook-failure behavior; then review OP and owner authorization with a separate operator. Keep a restorable world and plugin-data backup.
