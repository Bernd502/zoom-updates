# Testing SFMode

## Automated checks

Run with Java 21:

```sh
./gradlew clean test build
```

Current JUnit coverage exercises SQLite persistence across reopen, pending session state, snapshot hash verification, allowlist independence, audit queue persistence, origins/transfers/transformations, alerts, and pending recovery/rollback records. A Paper 1.21.11 + LuckPerms 5.5.71 smoke test verifies plugin load, console status, allowlist commands, and clean shutdown. It does not simulate an authenticated player or LuckPerms permission changes during a live session.

## Staging checklist

Use a disposable Paper 1.21.11 server and a non-owner test account. Back up the world and `plugins/SFMode/` before each run.

- Load LuckPerms before SFMode; confirm missing LuckPerms prevents enable.
- Authorize a UUID from console, grant only `sfmode.use`, and verify unauthorized toggles fail.
- Activate with occupied inventory, armor, offhand, cursor, survival/adventure modes, and existing OP/dev membership. Confirm no preexisting permission is removed.
- Remove `sfmode.use` while active and confirm the user can still disable.
- Stop/restart the process at every session state and verify no repeated snapshot restore and no privilege leak.
- Corrupt the SQLite snapshot and verify recovery refuses it while retaining the database backup.
- Move tagged items through player slots, containers, hoppers, drops, pickups, crafting and transformations; compare each log with actual behavior and keep all uncertain cases labeled uncertain.
- Roll back a session with split stacks, mixed origins, online and offline holders. Verify only resolvable tagged online stacks are removed and that preview/confirm is owner-bound and expires.
- Exercise every GUI click/drag with ordinary items on the cursor; verify no item is extracted or duplicated.
- Fill/lock the database and interrupt Discord. Confirm failure is visible, session elevation is suspended where possible, and the server remains responsive.
- Stop and restore spectator/monitor sessions; verify no player state is stranded.
