package net.sfmode;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Path;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;
class StoreTest {
    @TempDir Path root;
    @Test void snapshotAndSessionSurviveRestartWithoutConsumingBackup()throws Exception{
        UUID player=UUID.randomUUID(),session=UUID.randomUUID();byte[] bytes={1,2,3,4};Path file=root.resolve("sfmode.db");
        try(Store db=new Store(file)){
            db.authorize(player,"Tester");assertTrue(db.allowed(player));
            db.start(new Store.Session(session,player,"Tester","ACTIVATING","SURVIVAL",false,false,false,false),bytes);
            db.state(session,"ACTIVE",true,null);
        }
        try(Store db=new Store(file)){
            var s=db.pending(player);assertEquals(session,s.id());assertEquals("ACTIVE",s.state());assertTrue(s.grantedGroup());
            var snapshot=db.snapshot(session);assertArrayEquals(bytes,snapshot.bytes());assertEquals(Store.hash(bytes),snapshot.hash());
            db.state(session,"DEACTIVATING",false,null);assertArrayEquals(bytes,db.snapshot(session).bytes());
            db.state(session,"COMPLETED",false,null);assertNull(db.pending(player));assertArrayEquals(bytes,db.snapshot(session).bytes());
        }
    }
    @Test void authorizationAndAuditAreIndependent()throws Exception{try(Store db=new Store(root.resolve("audit.db"))){UUID id=UUID.randomUUID();db.authorize(id,"A");db.audit(null,id,"AUTHORIZATION","allowed",null,"OBSERVED");for(int i=0;i<200&&db.rows("audit",null,10).isEmpty();i++)Thread.sleep(10);assertEquals(1,db.rows("audit",null,10).size());db.disallow(id);assertFalse(db.allowed(id));assertEquals(1,db.rows("audit",null,10).size());}}
    @Test void hashDetectsCorruption()throws Exception{byte[] bytes={5,7,9};String before=Store.hash(bytes);bytes[1]=8;assertNotEquals(before,Store.hash(bytes));}
    @Test void originTransfersTransformationsAndAlertsPersistWithUncertainty()throws Exception{try(Store db=new Store(root.resolve("provenance.db"))){UUID player=UUID.randomUUID(),session=UUID.randomUUID(),origin=UUID.randomUUID();db.start(new Store.Session(session,player,"A","ACTIVE","SURVIVAL",false,false,false,false),new byte[]{1});db.origin(origin,session,player,"DIAMOND",64);db.transfer(origin,player,"CLICK",64,32,"STACK_IDENTITY_AMBIGUOUS");db.transformation(origin,"CRAFT","DIAMOND_SWORD","UNCERTAIN_SHIFT_BATCH");db.alert(session,"WARNING","large diamond stack");assertEquals("DIAMOND",db.origin(origin).b());var history=db.originHistory(origin);assertEquals(2,history.size());assertTrue(history.stream().anyMatch(x->x.d().equals("STACK_IDENTITY_AMBIGUOUS")));assertEquals(1,db.rows("alerts",null,10).size());}}
    @Test void pendingRecoveryAndRollbackRowsAreQueryable()throws Exception{try(Store db=new Store(root.resolve("ops.db"))){UUID player=UUID.randomUUID(),session=UUID.randomUUID(),op=UUID.randomUUID();db.start(new Store.Session(session,player,"A","RECOVERY_REQUIRED","SURVIVAL",false,false,false,false),new byte[]{2});db.recoveryRecord(op,session,player,"PREVIEW","manual review");db.rollbackRecord(op,session,player,"PREVIEW","no removals");assertEquals(1,db.pending().size());assertEquals("RECOVERY_REQUIRED",db.rows("recovery",null,10).getFirst().b());assertEquals("PREVIEW",db.rows("rollbacks",null,10).getFirst().b());}}
}
