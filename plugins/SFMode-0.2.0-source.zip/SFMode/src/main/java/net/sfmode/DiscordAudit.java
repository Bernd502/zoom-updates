package net.sfmode;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;
import java.net.URI;
import java.net.http.*;
import java.time.Duration;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/** Optional best-effort secondary channel. SQLite remains the authority. */
final class DiscordAudit implements AutoCloseable {
    private final JavaPlugin plugin;private final BlockingQueue<String> queue;private final ExecutorService worker;private final HttpClient client;private final URI url;private volatile boolean open=true;private final AtomicLong lastSend=new AtomicLong();
    DiscordAudit(JavaPlugin plugin){this.plugin=plugin;FileConfiguration config=plugin.getConfig();String raw=config.getString("discord.webhook-url","");URI parsed=null;
        if(config.getBoolean("discord.enabled")&&!raw.isBlank()){URI candidate=URI.create(raw);if(!candidate.getScheme().equals("https")||!candidate.getHost().equals("discord.com")&&!candidate.getHost().equals("discordapp.com")||!candidate.getPath().startsWith("/api/webhooks/"))throw new IllegalArgumentException("Discord webhook URL must use Discord HTTPS webhooks");parsed=candidate;}
        url=parsed;queue=new ArrayBlockingQueue<>(Math.max(1,Math.min(4096,config.getInt("discord.queue-size",256))));client=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();worker=Executors.newSingleThreadExecutor(r->{Thread t=new Thread(r,"sfmode-discord");t.setDaemon(true);return t;});if(url!=null)worker.submit(this::work);
    }
    boolean enabled(){return url!=null;}
    void offer(String message){if(url==null)return;String safe=message.replace('@','＠').replace('`','\'');if(!queue.offer(safe))plugin.getLogger().warning("SFMode Discord queue full; webhook notification dropped. SQLite audit remains authoritative.");}
    private void work(){while(open||!queue.isEmpty()){try{String message=queue.poll(1,TimeUnit.SECONDS);if(message==null)continue;long delay=Math.max(0,1000-(System.currentTimeMillis()-lastSend.get()));if(delay>0)Thread.sleep(delay);String json="{\"content\":\""+message.replace("\\","\\\\").replace("\"","\\\"").replace("\n"," ")+"\",\"allowed_mentions\":{\"parse\":[]}}";var request=HttpRequest.newBuilder(url).timeout(Duration.ofSeconds(10)).header("Content-Type","application/json").POST(HttpRequest.BodyPublishers.ofString(json)).build();int status=client.send(request,HttpResponse.BodyHandlers.discarding()).statusCode();lastSend.set(System.currentTimeMillis());if(status==429){Thread.sleep(3000);if(!queue.offer(message))plugin.getLogger().warning("SFMode Discord retry dropped after rate limit.");}else if(status>=500){Thread.sleep(2000);if(!queue.offer(message))plugin.getLogger().warning("SFMode Discord retry dropped after server error.");}else if(status>=400)plugin.getLogger().warning("SFMode Discord HTTP "+status+"; check webhook configuration.");}catch(InterruptedException e){Thread.currentThread().interrupt();break;}catch(Exception e){plugin.getLogger().warning("SFMode Discord send failed: "+e.getClass().getSimpleName());}}}
    @Override public void close(){open=false;worker.shutdownNow();}
}
