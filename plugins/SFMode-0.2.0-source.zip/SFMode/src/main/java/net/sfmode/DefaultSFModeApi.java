package net.sfmode;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import java.util.UUID;

final class DefaultSFModeApi implements SFModeApi {
    private final Tracking tracking;
    DefaultSFModeApi(Tracking tracking){this.tracking=tracking;}
    @Override public ItemStack tagCreatedItem(Player player,ItemStack item,String provider){return tracking.tagCreatedItem(player,item,provider);}
}
