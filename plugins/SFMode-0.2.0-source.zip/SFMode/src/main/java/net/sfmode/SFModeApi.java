package net.sfmode;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/** Optional service API for cooperating plugins that create admin-mode items. */
public interface SFModeApi {
    /**
     * Records an item created by a cooperating plugin during the player's active SFMode session.
     * The returned copy contains invisible SFMode PDC metadata; callers must use it as the created item.
     * This records a creation batch, not a unique physical item identity.
     * @param player creating administrator
     * @param item newly created stack
     * @param provider short plugin or feature label, never a secret
     * @return tagged stack, or the original copy if player is not in an active session
     */
    ItemStack tagCreatedItem(Player player, ItemStack item, String provider);
}
