package net.sfmode;

import java.nio.file.Path;
import java.security.MessageDigest;
import java.sql.*;
import java.time.Instant;
import java.util.*;

/** Single connection: all calls are made on the server thread, and important writes are committed before game state changes. */
final class Store implements AutoCloseable {
    private final Connection db;
    private final Connection auditDb;
    private record Audit(UUID session,UUID player,String category,String text,String world,Double x,Double y,Double z,String reliability){}
    private final java.util.concurrent.ArrayBlockingQueue<Audit> auditQueue=new java.util.concurrent.ArrayBlockingQueue<>(8192);
    private final Thread auditWriter;
    private volatile boolean closing;
    private volatile SQLException auditFailure;
    Store(Path file) throws Exception {
        String jdbc="jdbc:sqlite:"+file.toAbsolutePath();db=DriverManager.getConnection(jdbc);
        try(Statement s=db.createStatement()) {
            s.execute("PRAGMA journal_mode=WAL");s.execute("PRAGMA synchronous=FULL");s.execute("PRAGMA foreign_keys=ON");s.execute("PRAGMA busy_timeout=3000");
            s.execute("CREATE TABLE IF NOT EXISTS schema_version(version INTEGER NOT NULL)");
            s.execute("CREATE TABLE IF NOT EXISTS authorized_players(uuid TEXT PRIMARY KEY, name TEXT, added_at TEXT NOT NULL)");
            s.execute("CREATE TABLE IF NOT EXISTS sessions(id TEXT PRIMARY KEY, player TEXT NOT NULL, name TEXT NOT NULL, state TEXT NOT NULL, started TEXT NOT NULL, ended TEXT, old_mode TEXT NOT NULL, old_op INTEGER NOT NULL, old_flying INTEGER NOT NULL, old_allow_flight INTEGER NOT NULL, granted_group INTEGER NOT NULL DEFAULT 0, last_error TEXT)");
            s.execute("CREATE INDEX IF NOT EXISTS sessions_player ON sessions(player,started)");
            s.execute("CREATE TABLE IF NOT EXISTS snapshots(session_id TEXT PRIMARY KEY REFERENCES sessions(id), contents BLOB NOT NULL, sha256 TEXT NOT NULL, created TEXT NOT NULL)");
            s.execute("CREATE TABLE IF NOT EXISTS audit(id TEXT PRIMARY KEY, session_id TEXT, player TEXT, category TEXT NOT NULL, event_at TEXT NOT NULL, description TEXT NOT NULL, world TEXT, x REAL, y REAL, z REAL, reliability TEXT NOT NULL)");
            s.execute("CREATE INDEX IF NOT EXISTS audit_session ON audit(session_id,event_at)");
            s.execute("CREATE TABLE IF NOT EXISTS origins(id TEXT PRIMARY KEY, session_id TEXT NOT NULL, creator TEXT NOT NULL, material TEXT NOT NULL, quantity INTEGER NOT NULL, created TEXT NOT NULL, last_holder TEXT, confidence TEXT NOT NULL)");
            s.execute("CREATE INDEX IF NOT EXISTS origins_session ON origins(session_id,created)");
            s.execute("CREATE TABLE IF NOT EXISTS item_transfers(id TEXT PRIMARY KEY, origin_id TEXT NOT NULL, actor TEXT, event_type TEXT NOT NULL, before_count INTEGER, after_count INTEGER, observed TEXT NOT NULL, confidence TEXT NOT NULL)");
            s.execute("CREATE INDEX IF NOT EXISTS transfers_origin ON item_transfers(origin_id,observed)");
            s.execute("CREATE TABLE IF NOT EXISTS transformations(id TEXT PRIMARY KEY, origin_id TEXT NOT NULL, kind TEXT NOT NULL, output TEXT NOT NULL, occurred TEXT NOT NULL, quantity_status TEXT NOT NULL)");
            s.execute("CREATE TABLE IF NOT EXISTS tracked_blocks(world TEXT NOT NULL, x INTEGER NOT NULL, y INTEGER NOT NULL, z INTEGER NOT NULL, material TEXT NOT NULL, origin_id TEXT NOT NULL, placed TEXT NOT NULL, player TEXT NOT NULL, state TEXT NOT NULL, PRIMARY KEY(world,x,y,z))");
            s.execute("CREATE TABLE IF NOT EXISTS alerts(id TEXT PRIMARY KEY, session_id TEXT, severity TEXT NOT NULL, message TEXT NOT NULL, created TEXT NOT NULL, reviewed INTEGER NOT NULL DEFAULT 0)");
            s.execute("CREATE TABLE IF NOT EXISTS rollback_ops(id TEXT PRIMARY KEY, session_id TEXT NOT NULL, actor TEXT NOT NULL, state TEXT NOT NULL, created TEXT NOT NULL, details TEXT)");
            s.execute("CREATE TABLE IF NOT EXISTS recovery_ops(id TEXT PRIMARY KEY, session_id TEXT NOT NULL, actor TEXT NOT NULL, state TEXT NOT NULL, created TEXT NOT NULL, details TEXT)");
            s.execute("INSERT INTO schema_version(version) SELECT 1 WHERE NOT EXISTS(SELECT 1 FROM schema_version)");
            try(ResultSet integrity=s.executeQuery("PRAGMA integrity_check")){if(!integrity.next()||!"ok".equals(integrity.getString(1)))throw new SQLException("SQLite integrity check failed");}
        }
        auditDb=DriverManager.getConnection(jdbc);try(Statement s=auditDb.createStatement()){s.execute("PRAGMA journal_mode=WAL");s.execute("PRAGMA synchronous=FULL");s.execute("PRAGMA busy_timeout=3000");}
        auditWriter=new Thread(this::writeAudits,"sfmode-sqlite-audit");auditWriter.setDaemon(true);auditWriter.start();
    }
    record Session(UUID id,UUID player,String name,String state,String oldMode,boolean oldOp,boolean oldFlying,boolean oldAllowFlight,boolean grantedGroup){}
    record Snapshot(byte[] bytes,String hash){}
    static String hash(byte[] bytes) throws Exception {return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));}
    private static UUID id(String s){return UUID.fromString(s);}
    void authorize(UUID player,String name) throws SQLException {try(var p=db.prepareStatement("INSERT OR REPLACE INTO authorized_players VALUES(?,?,?)")){p.setString(1,player.toString());p.setString(2,name);p.setString(3,Instant.now().toString());p.executeUpdate();}}
    void disallow(UUID player) throws SQLException {try(var p=db.prepareStatement("DELETE FROM authorized_players WHERE uuid=?")){p.setString(1,player.toString());p.executeUpdate();}}
    boolean allowed(UUID player)throws SQLException {try(var p=db.prepareStatement("SELECT 1 FROM authorized_players WHERE uuid=?")){p.setString(1,player.toString());try(var r=p.executeQuery()){return r.next();}}}
    List<String> allowed()throws SQLException {List<String> out=new ArrayList<>();try(var p=db.prepareStatement("SELECT name,uuid FROM authorized_players ORDER BY name");var r=p.executeQuery()){while(r.next())out.add(r.getString(1)+" ("+r.getString(2)+")");}return out;}
    void start(Session s,byte[] backup)throws Exception {
        db.setAutoCommit(false);
        try(var p=db.prepareStatement("INSERT INTO sessions(id,player,name,state,started,old_mode,old_op,old_flying,old_allow_flight) VALUES(?,?,?,?,?,?,?,?,?)");var q=db.prepareStatement("INSERT INTO snapshots VALUES(?,?,?,?)")){
            p.setString(1,s.id.toString());p.setString(2,s.player.toString());p.setString(3,s.name);p.setString(4,s.state);p.setString(5,Instant.now().toString());p.setString(6,s.oldMode);p.setInt(7,s.oldOp?1:0);p.setInt(8,s.oldFlying?1:0);p.setInt(9,s.oldAllowFlight?1:0);p.executeUpdate();
            q.setString(1,s.id.toString());q.setBytes(2,backup);q.setString(3,hash(backup));q.setString(4,Instant.now().toString());q.executeUpdate();db.commit();
        }catch(Exception e){db.rollback();throw e;}finally{db.setAutoCommit(true);}
    }
    void state(UUID session,String state,boolean granted,String error)throws SQLException {try(var p=db.prepareStatement("UPDATE sessions SET state=?,granted_group=?,last_error=?,ended=CASE WHEN ?='COMPLETED' THEN ? ELSE ended END WHERE id=?")){p.setString(1,state);p.setInt(2,granted?1:0);p.setString(3,error);p.setString(4,state);p.setString(5,Instant.now().toString());p.setString(6,session.toString());p.executeUpdate();}}
    Session pending(UUID player)throws SQLException {try(var p=db.prepareStatement("SELECT id,player,name,state,old_mode,old_op,old_flying,old_allow_flight,granted_group FROM sessions WHERE player=? AND state<>'COMPLETED' ORDER BY started DESC LIMIT 1")){p.setString(1,player.toString());try(var r=p.executeQuery()){return r.next()?new Session(id(r.getString(1)),id(r.getString(2)),r.getString(3),r.getString(4),r.getString(5),r.getInt(6)!=0,r.getInt(7)!=0,r.getInt(8)!=0,r.getInt(9)!=0):null;}}}
    List<Session> pending()throws SQLException {List<Session> out=new ArrayList<>();try(var p=db.prepareStatement("SELECT id,player,name,state,old_mode,old_op,old_flying,old_allow_flight,granted_group FROM sessions WHERE state<>'COMPLETED' ORDER BY started DESC");var r=p.executeQuery()){while(r.next())out.add(new Session(id(r.getString(1)),id(r.getString(2)),r.getString(3),r.getString(4),r.getString(5),r.getInt(6)!=0,r.getInt(7)!=0,r.getInt(8)!=0,r.getInt(9)!=0));}return out;}
    Snapshot snapshot(UUID session)throws SQLException {try(var p=db.prepareStatement("SELECT contents,sha256 FROM snapshots WHERE session_id=?")){p.setString(1,session.toString());try(var r=p.executeQuery()){if(!r.next())throw new SQLException("Missing inventory backup");return new Snapshot(r.getBytes(1),r.getString(2));}}}
    void audit(UUID session,UUID player,String category,String text,org.bukkit.Location loc,String reliability)throws SQLException {
        if(auditFailure!=null)throw new SQLException("Audit writer has failed",auditFailure);
        Audit event=new Audit(session,player,category,text,loc==null||loc.getWorld()==null?null:loc.getWorld().getUID().toString(),loc==null?null:loc.getX(),loc==null?null:loc.getY(),loc==null?null:loc.getZ(),reliability);
        if(closing||!auditQueue.offer(event))throw new SQLException("Audit queue is full or shutting down; event was not accepted");
    }
    void auditCritical(UUID session,UUID player,String category,String text,org.bukkit.Location loc,String reliability)throws SQLException {
        try(var p=db.prepareStatement("INSERT INTO audit VALUES(?,?,?,?,?,?,?,?,?,?,?)")){
            p.setString(1,UUID.randomUUID().toString());p.setString(2,session==null?null:session.toString());p.setString(3,player==null?null:player.toString());p.setString(4,category);p.setString(5,Instant.now().toString());p.setString(6,text);p.setString(7,loc==null||loc.getWorld()==null?null:loc.getWorld().getUID().toString());p.setObject(8,loc==null?null:loc.getX());p.setObject(9,loc==null?null:loc.getY());p.setObject(10,loc==null?null:loc.getZ());p.setString(11,reliability);p.executeUpdate();
        }
    }
    SQLException auditFailure(){return auditFailure;}
    private void writeAudits(){while(!closing||!auditQueue.isEmpty()){try{Audit first=auditQueue.poll(500,java.util.concurrent.TimeUnit.MILLISECONDS);if(first==null)continue;var batch=new ArrayList<Audit>(128);batch.add(first);auditQueue.drainTo(batch,127);auditDb.setAutoCommit(false);try(var p=auditDb.prepareStatement("INSERT INTO audit VALUES(?,?,?,?,?,?,?,?,?,?,?)")){for(Audit e:batch){p.setString(1,UUID.randomUUID().toString());p.setString(2,e.session()==null?null:e.session().toString());p.setString(3,e.player()==null?null:e.player().toString());p.setString(4,e.category());p.setString(5,Instant.now().toString());p.setString(6,e.text());p.setString(7,e.world());p.setObject(8,e.x());p.setObject(9,e.y());p.setObject(10,e.z());p.setString(11,e.reliability());p.addBatch();}p.executeBatch();auditDb.commit();}catch(SQLException failure){auditDb.rollback();throw failure;}finally{auditDb.setAutoCommit(true);}}catch(InterruptedException interrupted){if(closing)continue;Thread.currentThread().interrupt();return;}catch(SQLException failure){auditFailure=failure;return;}}}

    record Row(String a,String b,String c,String d){}
    List<Row> rows(String table,String filter,int limit)throws SQLException {
        String sql=switch(table){case "audit"->"SELECT event_at,category,description,reliability FROM audit "+(filter==null?"":"WHERE session_id=? OR player=? ")+"ORDER BY event_at DESC LIMIT ?";case "origins"->"SELECT created,material,id,confidence FROM origins "+(filter==null?"":"WHERE session_id=? OR creator=? ")+"ORDER BY created DESC LIMIT ?";case "sessions"->"SELECT started,name,id,state FROM sessions "+(filter==null?"":"WHERE player=? OR id=? ")+"ORDER BY started DESC LIMIT ?";case "alerts"->"SELECT created,severity,id,message FROM alerts ORDER BY created DESC LIMIT ?";case "rollbacks"->"SELECT created,state,id,details FROM rollback_ops ORDER BY created DESC LIMIT ?";case "recovery"->"SELECT started,state,id,name FROM sessions WHERE state<>'COMPLETED' ORDER BY started DESC LIMIT ?";default->throw new IllegalArgumentException();};
        List<Row> out=new ArrayList<>();try(var p=db.prepareStatement(sql)){int at=1;if(filter!=null&&!table.equals("alerts")){p.setString(at++,filter);p.setString(at++,filter);}p.setInt(at,limit);try(var r=p.executeQuery()){while(r.next())out.add(new Row(r.getString(1),r.getString(2),r.getString(3),r.getString(4)));}}return out;
    }
    void origin(UUID id,UUID session,UUID creator,String material,int amount)throws SQLException{try(var p=db.prepareStatement("INSERT INTO origins VALUES(?,?,?,?,?,?,?,?)")){p.setString(1,id.toString());p.setString(2,session.toString());p.setString(3,creator.toString());p.setString(4,material);p.setInt(5,amount);p.setString(6,Instant.now().toString());p.setString(7,creator.toString());p.setString(8,"CREATION_OBSERVED");p.executeUpdate();}}
    Row origin(UUID id)throws SQLException{try(var p=db.prepareStatement("SELECT created,material,creator,session_id FROM origins WHERE id=?")){p.setString(1,id.toString());try(var r=p.executeQuery()){return r.next()?new Row(r.getString(1),r.getString(2),r.getString(3),r.getString(4)):null;}}}
    void transfer(UUID origin,UUID actor,String event,int before,int after,String confidence)throws SQLException{try(var p=db.prepareStatement("INSERT INTO item_transfers VALUES(?,?,?,?,?,?,?,?)")){p.setString(1,UUID.randomUUID().toString());p.setString(2,origin.toString());p.setString(3,actor==null?null:actor.toString());p.setString(4,event);p.setInt(5,before);p.setInt(6,after);p.setString(7,Instant.now().toString());p.setString(8,confidence);p.executeUpdate();}}
    void transformation(UUID origin,String kind,String output,String quantity)throws SQLException{try(var p=db.prepareStatement("INSERT INTO transformations VALUES(?,?,?,?,?,?)")){p.setString(1,UUID.randomUUID().toString());p.setString(2,origin.toString());p.setString(3,kind);p.setString(4,output);p.setString(5,Instant.now().toString());p.setString(6,quantity);p.executeUpdate();}}
    void block(org.bukkit.block.Block block,UUID origin,UUID player)throws SQLException{try(var p=db.prepareStatement("INSERT OR REPLACE INTO tracked_blocks VALUES(?,?,?,?,?,?,?,?,?)")){p.setString(1,block.getWorld().getUID().toString());p.setInt(2,block.getX());p.setInt(3,block.getY());p.setInt(4,block.getZ());p.setString(5,block.getType().name());p.setString(6,origin.toString());p.setString(7,Instant.now().toString());p.setString(8,player.toString());p.setString(9,"PLACED");p.executeUpdate();}}
    UUID breakBlock(org.bukkit.block.Block block)throws SQLException{try(var p=db.prepareStatement("SELECT origin_id,material FROM tracked_blocks WHERE world=? AND x=? AND y=? AND z=? AND state='PLACED'")){p.setString(1,block.getWorld().getUID().toString());p.setInt(2,block.getX());p.setInt(3,block.getY());p.setInt(4,block.getZ());try(var r=p.executeQuery()){if(!r.next())return null;UUID origin=UUID.fromString(r.getString(1));try(var update=db.prepareStatement("UPDATE tracked_blocks SET state=? WHERE world=? AND x=? AND y=? AND z=?")){update.setString(1,r.getString(2).equals(block.getType().name())?"BROKEN":"STALE");update.setString(2,block.getWorld().getUID().toString());update.setInt(3,block.getX());update.setInt(4,block.getY());update.setInt(5,block.getZ());update.executeUpdate();}return origin;}}}
    void recoveryRecord(UUID id,UUID session,UUID actor,String state,String details)throws SQLException{try(var p=db.prepareStatement("INSERT OR REPLACE INTO recovery_ops VALUES(?,?,?,?,?,?)")){p.setString(1,id.toString());p.setString(2,session.toString());p.setString(3,actor.toString());p.setString(4,state);p.setString(5,Instant.now().toString());p.setString(6,details);p.executeUpdate();}}
    void rollbackRecord(UUID id,UUID session,UUID actor,String state,String details)throws SQLException{try(var p=db.prepareStatement("INSERT OR REPLACE INTO rollback_ops VALUES(?,?,?,?,?,?)")){p.setString(1,id.toString());p.setString(2,session.toString());p.setString(3,actor.toString());p.setString(4,state);p.setString(5,Instant.now().toString());p.setString(6,details);p.executeUpdate();}}
    String latestActivity(UUID session)throws SQLException{try(var p=db.prepareStatement("SELECT category||': '||description FROM audit WHERE session_id=? ORDER BY event_at DESC LIMIT 1")){p.setString(1,session.toString());try(var r=p.executeQuery()){return r.next()?r.getString(1):"No recorded actions";}}}
    void reviewAlert(UUID id)throws SQLException{try(var p=db.prepareStatement("UPDATE alerts SET reviewed=1 WHERE id=?")){p.setString(1,id.toString());p.executeUpdate();}}
    void alert(UUID session,String severity,String message)throws SQLException{try(var p=db.prepareStatement("INSERT INTO alerts VALUES(?,?,?,?,?,0)")){p.setString(1,UUID.randomUUID().toString());p.setString(2,session.toString());p.setString(3,severity);p.setString(4,message);p.setString(5,Instant.now().toString());p.executeUpdate();}}
    List<Row> originHistory(UUID origin)throws SQLException{List<Row> out=new ArrayList<>();String needle=origin.toString();try(var a=db.prepareStatement("SELECT event_at,category,description,reliability FROM audit WHERE description LIKE ? ORDER BY event_at DESC LIMIT 100");var t=db.prepareStatement("SELECT occurred,kind,output,quantity_status FROM transformations WHERE origin_id=? ORDER BY occurred DESC LIMIT 100");var m=db.prepareStatement("SELECT observed,event_type,actor,confidence FROM item_transfers WHERE origin_id=? ORDER BY observed DESC LIMIT 100")){a.setString(1,"%"+needle+"%");try(var r=a.executeQuery()){while(r.next())out.add(new Row(r.getString(1),r.getString(2),r.getString(3),r.getString(4)));}t.setString(1,needle);try(var r=t.executeQuery()){while(r.next())out.add(new Row(r.getString(1),r.getString(2),r.getString(3),r.getString(4)));}m.setString(1,needle);try(var r=m.executeQuery()){while(r.next())out.add(new Row(r.getString(1),"TRANSFER "+r.getString(2),r.getString(3),r.getString(4)));}}out.sort(Comparator.comparing(Row::a).reversed());return out;}
    @Override public void close()throws SQLException{closing=true;auditWriter.interrupt();try{auditWriter.join(10_000);}catch(InterruptedException e){Thread.currentThread().interrupt();throw new SQLException("Interrupted while flushing audit queue",e);}if(auditWriter.isAlive())throw new SQLException("Audit writer did not stop within 10 seconds; "+auditQueue.size()+" events remain queued");if(auditFailure!=null)throw new SQLException("Audit writer failed; "+auditQueue.size()+" events remain queued",auditFailure);auditDb.close();db.close();}
}
