package net.sfmode;

import net.luckperms.api.LuckPerms;
import net.luckperms.api.model.user.User;
import net.luckperms.api.node.types.InheritanceNode;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.CompletionException;

/** Fail-closed session transitions. SQLite snapshots are durable before any gameplay mutation. */
final class Sessions {
    private final JavaPlugin plugin;private final Store db;private final LuckPerms lp;private final String group;private final DiscordAudit discord;
    private final Set<UUID> busy=new HashSet<>();private final Map<UUID,Long> last=new HashMap<>();
    Sessions(JavaPlugin plugin,Store db,LuckPerms lp,String group,DiscordAudit discord){this.plugin=plugin;this.db=db;this.lp=lp;this.group=group;this.discord=discord;}
    boolean busy(UUID id){return busy.contains(id);}
    boolean active(UUID id){try{var s=db.pending(id);return s!=null&&s.state().equals("ACTIVE");}catch(Exception e){fail(e);return false;}}
    Store.Session pending(UUID id){try{return db.pending(id);}catch(Exception e){fail(e);return null;}}
    void toggle(Player p){UUID id=p.getUniqueId();try{
        if(busy.contains(id)){p.sendMessage("§c[SFMode] A transition is already running.");return;}
        long now=System.currentTimeMillis();if(now-last.getOrDefault(id,0L)<plugin.getConfig().getLong("toggle-cooldown-seconds",5)*1000){p.sendMessage("§c[SFMode] Wait before toggling again.");return;}
        var current=db.pending(id);if(current!=null&&!current.state().equals("ACTIVE")){p.sendMessage("§c[SFMode] Recovery is required; your inventory is locked.");return;}
        last.put(id,now);busy.add(id);if(current==null)activate(p);else deactivate(p,current,false);
    }catch(Exception e){busy.remove(id);fail(e);p.sendMessage("§c[SFMode] Failed safely: "+e.getMessage());}}
    private void activate(Player p)throws Exception{
        UUID id=p.getUniqueId();if(!db.allowed(id)||!p.hasPermission("sfmode.use")){busy.remove(id);p.sendMessage("§c[SFMode] You are not authorized.");return;}
        if(lp==null){busy.remove(id);p.sendMessage("§c[SFMode] LuckPerms is unavailable.");return;}
        byte[] bytes=InventoryBackup.capture(p);var s=new Store.Session(UUID.randomUUID(),id,p.getName(),"ACTIVATING",p.getGameMode().name(),p.isOp(),p.isFlying(),p.getAllowFlight(),false);
        db.start(s,bytes);audit(s,"SESSION","Activation started; inventory snapshot committed",p);
        lp.getUserManager().loadUser(id).whenComplete((user,loadError)->Bukkit.getScheduler().runTask(plugin,()->{
            if(loadError!=null||user==null){finishActivation(p,s,false,loadError==null?new IllegalStateException("LuckPerms user unavailable"):loadError);return;}
            boolean had=user.getNodes().stream().anyMatch(n->n instanceof InheritanceNode i&&i.getGroupName().equalsIgnoreCase(group));
            boolean granted=!had;
            try{db.state(s.id(),"ACTIVATING",granted,null);}catch(Exception failure){finishActivation(p,s,false,failure);return;}
            if(had){finishActivation(p,s,false,null);return;}
            user.data().add(InheritanceNode.builder(group).build());
            lp.getUserManager().saveUser(user).whenComplete((ignored,saveError)->Bukkit.getScheduler().runTask(plugin,()->finishActivation(p,s,true,saveError)));
        }));
    }
    private void finishActivation(Player p,Store.Session s,boolean granted,Throwable error){UUID id=s.player();try{
        if(error!=null||!p.isOnline()){db.state(s.id(),"RECOVERY_REQUIRED",granted,error==null?"Disconnected during activation":"LuckPerms save failed");if(p.isOnline())p.sendMessage("§c[SFMode] Activation stopped; recovery required.");return;}
        p.getInventory().clear();p.setItemOnCursor(null);p.setGameMode(GameMode.CREATIVE);if(!p.isOp())p.setOp(true);
        db.state(s.id(),"ACTIVE",granted,null);audit(s,"PERMISSIONS","Temporary OP="+(!s.oldOp())+", LuckPerms group="+granted,p);
        plugin.getLogger().warning("SFMode elevated "+p.getName()+" session "+s.id());discord.offer("SFMode session started: "+p.getName()+" / "+s.id());
        p.sendMessage("§a[SFMode] Administrator mode ENABLED. Your inventory was saved. Actions are being recorded.");
    }catch(Exception failure){restrict(p,s);markRecovery(s,failure);p.sendMessage("§c[SFMode] Activation interrupted; inventory recovery required.");}
    finally{busy.remove(id);}}

    private void deactivate(Player p,Store.Session s,boolean recovery)throws Exception{
        db.state(s.id(),"DEACTIVATING",s.grantedGroup(),null);
        audit(s,"SESSION",recovery?"Recovery started":"Deactivation started",p);
        revoke(p,s,()->{
            try{
                if(!p.isOnline()){db.state(s.id(),"INTERRUPTED_ACTIVE",false,"Disconnected before inventory restoration");return;}
                var backup=db.snapshot(s.id());if(!Store.hash(backup.bytes()).equals(backup.hash()))throw new IllegalStateException("Inventory snapshot checksum mismatch");
                var contents=InventoryBackup.decode(backup.bytes());
                // Restoring an already restored snapshot is harmless only if it is byte-identical.
                p.getInventory().clear();p.setItemOnCursor(null);
                p.setOp(s.oldOp());p.setGameMode(GameMode.valueOf(s.oldMode()));p.setAllowFlight(s.oldAllowFlight());if(s.oldAllowFlight())p.setFlying(s.oldFlying());
                InventoryBackup.restore(p,contents);
                db.state(s.id(),"COMPLETED",false,null);audit(s,"SESSION",recovery?"Recovered original inventory":"Session completed; original inventory restored",p);
                plugin.getLogger().warning("SFMode restored "+p.getName()+" session "+s.id());discord.offer("SFMode session ended: "+p.getName()+" / "+s.id());
                p.sendMessage("§a[SFMode] Administrator mode DISABLED. Your original inventory was restored.");
            }catch(Exception error){restrict(p,s);markRecovery(s,error);p.sendMessage("§c[SFMode] Restoration paused. Backup retained; owner recovery required.");}
            finally{busy.remove(p.getUniqueId());}
        });
    }
    private void revoke(Player p,Store.Session s,Runnable next){
        if(!s.grantedGroup()){next.run();return;}
        lp.getUserManager().loadUser(s.player()).thenCompose(user->{
            user.data().remove(InheritanceNode.builder(group).build());return lp.getUserManager().saveUser(user);
        }).whenComplete((v,error)->Bukkit.getScheduler().runTask(plugin,()->{
            if(error!=null){markRecovery(s,error);busy.remove(s.player());if(p.isOnline())p.sendMessage("§c[SFMode] LuckPerms revocation failed; recovery required.");return;}
            try{db.state(s.id(),"DEACTIVATING",false,null);}catch(Exception e){markRecovery(s,e);busy.remove(s.player());return;}
            next.run();
        }));
    }
    void recover(Player p,boolean force){try{
        var s=db.pending(p.getUniqueId());if(s==null){p.sendMessage("§7[SFMode] No pending session.");return;}
        if(busy.contains(s.player()))return;
        var backup=db.snapshot(s.id());if(!Store.hash(backup.bytes()).equals(backup.hash())){p.sendMessage("§c[SFMode] Backup checksum failed. Do not restore.");return;}
        if(!Set.of("ACTIVE","DEACTIVATING","INTERRUPTED_ACTIVE").contains(s.state())){
            // A snapshot taken during activation is not proof that the original inventory
            // was cleared. Only complete it automatically when the original items match.
            if(!InventoryBackup.matches(p,InventoryBackup.decode(backup.bytes()))&&!force){
                db.state(s.id(),"RECOVERY_REQUIRED",s.grantedGroup(),"Activation inventory conflict; owner confirmation required");
                p.sendMessage("§c[SFMode] Inventory conflict. Backup retained; owner confirmation required.");return;
            }
        }
        busy.add(s.player());deactivate(p,s,true);
    }catch(Exception e){busy.remove(p.getUniqueId());fail(e);p.sendMessage("§c[SFMode] Recovery failed; backup retained.");}}
    void onQuit(Player p){var s=pending(p.getUniqueId());if(s==null)return;
        boolean active=Set.of("ACTIVE","DEACTIVATING","INTERRUPTED_ACTIVE").contains(s.state());
        try{db.state(s.id(),active?"INTERRUPTED_ACTIVE":"RECOVERY_REQUIRED",s.grantedGroup(),"Player disconnected");if(!s.oldOp())p.setOp(false);audit(s,"SESSION","Disconnected; recovery required",p);}catch(Exception e){fail(e);}
        // A pending asynchronous LP grant can still finish after this event; the
        // durable granted_group flag tells recovery which node is ours to remove.
        if(s.grantedGroup())lp.getUserManager().loadUser(s.player()).thenCompose(user->{user.data().remove(InheritanceNode.builder(group).build());return lp.getUserManager().saveUser(user);}).whenComplete((v,e)->Bukkit.getScheduler().runTask(plugin,()->{try{db.state(s.id(),active?"INTERRUPTED_ACTIVE":"RECOVERY_REQUIRED",e!=null,"Disconnected; group revocation "+(e==null?"completed":"failed"));}catch(Exception x){fail(x);}}));
    }
    void onJoin(Player p){var s=pending(p.getUniqueId());if(s==null)return;if(!s.oldOp())p.setOp(false);
        p.sendMessage("§e[SFMode] An unfinished administrator session is being checked.");
        // Rejoin is restricted until recovery finishes or an owner reviews an ambiguous state.
        if(Set.of("ACTIVE","DEACTIVATING","INTERRUPTED_ACTIVE").contains(s.state()))recover(p,false);else try{db.state(s.id(),"RECOVERY_REQUIRED",s.grantedGroup(),"Review interrupted activation before restore");}catch(Exception e){fail(e);}
    }
    void shutdown(){for(Player p:Bukkit.getOnlinePlayers())if(pending(p.getUniqueId())!=null)onQuit(p);}
    void suspend(Player p){var s=pending(p.getUniqueId());if(s==null)return;restrict(p,s);try{db.state(s.id(),"RECOVERY_REQUIRED",s.grantedGroup(),"Audit persistence unavailable");}catch(Exception e){fail(e);}p.sendMessage("§c[SFMode] Audit storage failed. Elevated mode suspended; owner recovery required.");}
    private void restrict(Player p,Store.Session s){try{if(!s.oldOp())p.setOp(false);p.setGameMode(GameMode.SURVIVAL);p.setAllowFlight(false);}catch(Exception e){fail(e);}}
    private void audit(Store.Session s,String category,String msg,Player p)throws Exception{db.auditCritical(s.id(),s.player(),category,msg,p.getLocation(),"OBSERVED");}
    private void markRecovery(Store.Session s,Throwable e){try{db.state(s.id(),"RECOVERY_REQUIRED",s.grantedGroup(),e.toString());}catch(Exception x){fail(x);}fail(e);}
    private void fail(Throwable e){plugin.getLogger().severe("SFMode transition failure: "+e.getClass().getSimpleName()+": "+e.getMessage());}
}
