package net.sfmode;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import java.io.*;

/** Bounded, versioned Paper item codec; avoids Java object deserialization for recovery data. */
final class InventoryBackup {
    private static final int VERSION=2,MAX_SLOTS=128,MAX_ITEM_BYTES=1_048_576,MAX_SNAPSHOT_BYTES=16*1024*1024;
    record Contents(ItemStack[] storage,ItemStack[] armor,ItemStack[] extra,ItemStack cursor,int held){}
    static byte[] capture(Player p)throws IOException{
        var inv=p.getInventory();try(var bytes=new ByteArrayOutputStream();var out=new DataOutputStream(bytes)){
            out.writeInt(VERSION);writeItems(out,inv.getStorageContents());writeItems(out,inv.getArmorContents());writeItems(out,inv.getExtraContents());writeItem(out,p.getItemOnCursor());out.writeInt(inv.getHeldItemSlot());out.flush();
            if(bytes.size()>MAX_SNAPSHOT_BYTES)throw new IOException("Inventory snapshot exceeds the safe size limit");return bytes.toByteArray();
        }
    }
    static Contents decode(byte[] bytes)throws IOException{
        if(bytes==null||bytes.length>MAX_SNAPSHOT_BYTES)throw new IOException("Inventory snapshot is missing or too large");
        try(var in=new DataInputStream(new ByteArrayInputStream(bytes))){if(in.readInt()!=VERSION)throw new IOException("Unknown inventory snapshot format");ItemStack[] storage=readItems(in),armor=readItems(in),extra=readItems(in);ItemStack cursor=readItem(in);int held=in.readInt();if(in.available()!=0||held<0||held>8)throw new IOException("Malformed inventory snapshot");return new Contents(storage,armor,extra,cursor,held);}
        catch(EOFException|IllegalArgumentException invalid){throw new IOException("Malformed inventory snapshot",invalid);}
    }
    private static void writeItems(DataOutputStream out,ItemStack[] items)throws IOException{if(items.length>MAX_SLOTS)throw new IOException("Inventory has too many slots");out.writeInt(items.length);for(ItemStack item:items)writeItem(out,item);}
    private static ItemStack[] readItems(DataInputStream in)throws IOException{int count=in.readInt();if(count<0||count>MAX_SLOTS)throw new IOException("Invalid inventory slot count");ItemStack[] result=new ItemStack[count];for(int i=0;i<count;i++)result[i]=readItem(in);return result;}
    private static void writeItem(DataOutputStream out,ItemStack item)throws IOException{if(item==null||item.getType().isAir()){out.writeInt(-1);return;}byte[] bytes=item.serializeAsBytes();if(bytes.length>MAX_ITEM_BYTES)throw new IOException("Item data exceeds the safe size limit");out.writeInt(bytes.length);out.write(bytes);}
    private static ItemStack readItem(DataInputStream in)throws IOException{int length=in.readInt();if(length==-1)return null;if(length<0||length>MAX_ITEM_BYTES||length>in.available())throw new IOException("Invalid item data length");byte[] bytes=in.readNBytes(length);if(bytes.length!=length)throw new EOFException();return ItemStack.deserializeBytes(bytes);}
    static boolean matches(Player p,Contents c){var inv=p.getInventory();return java.util.Arrays.equals(inv.getStorageContents(),c.storage)
            &&java.util.Arrays.equals(inv.getArmorContents(),c.armor)
            &&java.util.Arrays.equals(inv.getExtraContents(),c.extra)
            &&java.util.Objects.equals(p.getItemOnCursor(),c.cursor)&&inv.getHeldItemSlot()==c.held;}
    static void restore(Player p,Contents c){var inv=p.getInventory();inv.clear();inv.setStorageContents(c.storage);inv.setArmorContents(c.armor);inv.setExtraContents(c.extra);p.setItemOnCursor(c.cursor);inv.setHeldItemSlot(c.held);p.updateInventory();}
}
